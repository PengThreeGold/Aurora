# 企业级 AI Agent 框架选型说明书

版本 2.0 · 整合与复核日期：2026-10-07 · 通用选型，独立于现有业务背景

本说明书帮助架构与开发团队在 LangChain、LangGraph、Google ADK 和 Eino 中选择合适路线。内容覆盖设计、开发、交互、恢复、安全、并发、测试、发布、数据治理、维护与成本。读者可以先完成场景决策，再沿编号查评分理由与证据。

**技术路线建议：复杂且需要恢复的流程，推荐 LangGraph 作为编排核心；常规聊天和工具循环，推荐 LangChain；希望统一 Agent 开发与评测，或采用受支持实时语音链路，推荐 Google ADK；明确要求 Go 集成或交付，优先 Eino。** 每项建议都有前提和换选条件。性能与生产稳定性的相对优胜结论尚未取得。

阅读路线：决策者先读“范围与场景决策”；架构师读“比较矩阵”与关键能力分析；实现与验收人员读“核心代码”和“采用前验收”。所有完整代码、数据与复现说明均在同目录的唯一附件 `Agent框架选型附件.zip` 中。

## 范围与评估基线

本版比较开源框架与明确标出的扩展路径，不代入当前业务的运行时、并发数、数据库或预算。此前的评分与场景指南已经并入本文；读完本文不需要再打开另一个说明文档。


| 候选 | 本版基线 | 主要责任 | 使用边界 |
| --- | --- | --- | --- |
| LangChain | Python 1.4.3 | 高层Agent循环、模型/工具与middleware | Agent建立在LangGraph上，底层能力不重复扣分 |
| LangGraph | Python 1.2.13 | 显式state、节点、边、持久执行 | 库本身不是任务调度与租户管理平台 |
| Google ADK | Python 2.11.0 | Agent、Runner、Session、Workflow及eval | 各语言SDK和旧版/2.x路径分别核对 |
| Eino | Go v0.9.21 | compose、ADK、middleware及组件 | 扩展与存储实现另行锁定版本 |


上述是2026-10-06研究时锁定的评估基线，本次整合没有把它们更新成“今天最新版本”。在线文档可能已演进，生产采用时应按锁定组合重新验证。核心包、provider、saver、协议adapter及商业平台有各自版本和许可。

LangChain 与 LangGraph可以组合使用；Google ADK已有图工作流；Eino兼有Agent与显式编排。Python与Go列是不同语言路线，不能把语言偏好直接换算成框架性能分。Deep Agents、LangSmith、AG-UI、A2UI和MCP Apps在本文中按扩展或协议讨论。[S01](#source-s01)、[S03](#source-s03)、[S04](#source-s04)、[S17](#source-s17)、[S18](#source-s18)、[S19](#source-s19)、[S26](#source-s26)、[S63](#source-s63)。


## 场景决策


“首选”表示在该行前提成立时建议采用的路线；“换选条件”说明什么证据或约束会改变结论。选择框架后仍要完成部署与业务验收。

| 场景与典型任务 | 首选路线 | 为什么选它 | 何时改选 | 对应比较点 |
|---|---|---|---|---|
| 常规聊天、查询、少量工具调用；无特殊流程拓扑 | **LangChain** | create_agent 与 middleware 减少循环控制和接入代码 | 出现必须固定的分支、并行汇总、多处等待或细粒度恢复，使用 LangGraph 控制外层流程 | A1、A3、B1、C1 |
| 审批后执行、长任务、故障后继续、复杂分支与并行 | **LangGraph** | state、节点、边和 checkpoint 让执行边界更清楚 | Go 是硬性要求时转 Eino；ADK 的 Workflow 满足全部流程且团队已有 ADK 基础时优先复用 | C1/C2、D1–D4、I3 |
| 单轮知识问答、检索后回答、多数据源接入 | **LangChain 加检索组件** | 可以复用模型与数据集成，简单场景无需设计复杂图 | 需要多阶段检索、交叉验证、人工补充和失败分支时转 LangGraph；Go 环境转 Eino | B1、M3、C1 |
| 多个 Agent 分工，希望统一 session、运行入口和质量评测 | **Google ADK** | Agent、Session、Workflow 与 evaluation 有共同的开发路径 | 自定义状态流转与故障边界比统一入口更重要时选 LangGraph；不能接受相关实验性组件时重新评估使用范围 | C3、H2、M1、J1 |
| Go 团队，需要在 Go 服务中集成 Agent 或以 Go 程序交付 | **Eino** | compose、ADK、Go 类型和现有 Go 业务函数可组合，减少跨语言运行维护 | 目标 provider/协议缺少可用扩展，或补齐恢复、存储的成本高于维护 Python 服务时选 LangGraph；ADK Go 另做 SDK 对照 | A2、I4、B3、D1、I2 |
| 实时语音、用户插话、持续音视频交互 | **Google ADK 的 Live 路线**，前提是支持目标模型与客户端链路 | 四个候选中，本次确认了其专门的 Live/Voice 开发路径 | 模型或音频链路不受支持时，单独选择实时运行组件，再用 LangGraph 等组织后台业务；不能把普通 token streaming 当替代 | N2、N1、E1 |
| Agent 拉起页面、生成表单/组件，用户操作后继续复杂任务 | **LangGraph 加独立的 UI 协议与 renderer** | 后端多步骤交互由图控制，前端呈现由协议与组件系统负责 | 只有少量固定表单时 LangChain 已足够；Go 硬约束时 Eino；已有 ADK 前端适配时复用 ADK | D3、E1–E4、F1 |
| 多租户 SaaS，有资源配额、权限和审计要求 | **复杂业务默认 LangGraph，加独立授权、任务调度和租户数据治理** | 编排可控便于划分策略执行点；安全与公平调度仍独立实现 | Go 交付优先时选 Eino 加相同治理；若要求安装框架即可获得完整租户隔离，这四个开源库单独都不满足 | F1–F4、G4、H4、I3 |
| 私有化、禁止公网依赖 | **按业务复杂度选 LangChain/LangGraph；Go 交付选 Eino** | 私有化本身不排除这几种库；关键是模型、存储和扩展的实际外联要求 | 已有 ADK 私有化部署经验可选 ADK；任何方案存在无法关闭的外联或不可接受许可时淘汰该具体组合 | I1、I4、K1/K2 |
| 目标是最低内存、最高吞吐或最低总成本 | **不能仅据当前数据指定冠军；按上述场景先定功能基线，再以同场测试决定** | 当前没有四框架相同负载的结果；语言特性不能换算为端到端性能 | 同硬件、同模型、同持久性与正确性要求下测得不达标，即更换部署方案或框架 | L1–L4、G1、K2/K3 |

上表 AI2UI、SaaS、私有化组合是本文的架构建议，不是已完成集成验证的产品清单。相关原生机制和限制见下文相应编号；AG-UI、A2UI 和 MCP Apps 的职责也需分别核实。[Streaming](https://docs.langchain.com/oss/python/langgraph/streaming)、[AG-UI](https://docs.ag-ui.com/introduction)、[A2UI](https://a2ui.org/specification/v0.9.1-a2ui/)、[MCP Apps](https://github.com/modelcontextprotocol/ext-apps)。

### 为什么复杂可恢复流程推荐 LangGraph

此处“复杂”有具体含义：存在必须执行的业务校验、明确分支、并行汇总、多次等待用户、进程退出后的继续执行，而不是单纯 prompt 很长或工具很多。这类系统需要把模型决策放在可检查的流程中。LangGraph 的直接图编排、状态管理与持久化契约覆盖这些需求，所以在没有语言硬约束时，本报告推荐它作为默认编排核心。[Graph API](https://docs.langchain.com/oss/python/langgraph/graph-api)、[Checkpointers](https://docs.langchain.com/oss/python/langgraph/checkpointers)、[Interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts)。

选择它需要接受两项成本：团队要明确设计 state、节点边界和重试语义；还要建设任务调度、权限、幂等、存储运维和前端接入。LangGraph 不是完整运营平台。如果任务只是问答与工具循环，这些设计可能增加不必要的维护工作，此时 LangChain 更合适。

本地 C07 已验证 LangGraph 的有限恢复路径，因此此建议除了文档还有局部实测依据。但 ADK 和 Eino 没有在本次完成相同恢复实验，不能据此宣称它们恢复更差。选择 LangGraph 的理由是能力与该场景的匹配程度；性能、生产稳定性和整体成本仍未形成比较结论。

### 采用与换选条件

| 框架 | 建议采用的前提 | 不建议作为默认选择的情况 | 改变结论的关键证据 |
|---|---|---|---|
| LangChain | 常规 Agent 循环已满足需求，重视模型/工具接入速度 | 大量业务逻辑被迫塞进 middleware，状态与顺序已经难以解释 | 增加 LangGraph 外层流程后，能否明显简化业务分支与恢复逻辑 |
| LangGraph | 必须显式控制流程与状态，并愿意维护编排代码 | 简单任务没有用到图的控制能力；或目标平台不能接受相应运行时 | 目标数据库恢复、重复操作防护、跨版本任务继续执行是否通过 |
| Google ADK | 希望用统一的 Agent、session、eval 路线，或目标实时交互属于已支持范围 | 必需集成与所选 2.x 路线不兼容；关键能力仅实验性且不能接受变动 | 精确到 SDK/模型/transport 的兼容测试，以及 Workflow 恢复与升级测试 |
| Eino | Go 是实际工程要求，目标模型与工具已有可用 Go 接入 | 仅凭“Go 更快”选型，但没有性能数据；缺失组件造成大量自建 | 编译交付、真实存储恢复、目标协议兼容和端到端容量的实际结果 |

Eino 特定 Workflow Agent 的上下文共享限制已经在 v0.9.21 源码中核对；它应影响协作模式选择，不能扩大成“整个 Eino 不适合企业”。同样，ADK 的图编排已经存在，不能继续用早期能力边界评价当前版本。[Eino v0.9.21 Workflow Agent 源码](https://raw.githubusercontent.com/cloudwego/eino/v0.9.21/adk/workflow.go)、[ADK graph workflows](https://adk.dev/graphs/)。

### 从推荐到实际决策

1. **先确定不能违反的条件。** 例如必须 Go、必须离线、指定数据库或指定语音模型；只有真实硬约束才能淘汰路线，不用偏好冒充限制。
2. **按最主要的任务形态选首选。** 普通循环选 LangChain，满足显式流程与恢复前提时选 LangGraph，统一 ADK 开发评测或受支持 Live 场景选 ADK，Go 交付选 Eino。
3. **为首选指定一个确实可能替代它的备选。** 例如复杂流程用 LangGraph 对照 ADK Workflow；Go 工程用 Eino 对照单独核实过的 ADK Go，不把 Python ADK 的分数直接移给 Go。
4. **用能推翻首选的实验验收。** 测试崩溃后是否重复外部操作、权限撤销后能否继续越权、UI 重复提交、升级后的旧任务、资源与时延预算。失败意味着修正组合或换选，不以总分较高为理由放行。

**本报告已经给出技术路线结论；生产上线结论需要上述验收。** 不计算无场景总分，是为了避免把无关能力加在一起，不是回避推荐。后续可给每种明确场景设置权重，但不能用加权得分抵消权限隔离或业务正确性失败。


### 决策优先级与可能改变推荐的证据

LangGraph的默认推荐限定在“显式复杂流程、持久恢复、可接受其运行时、团队能维护编排代码”这组条件。本文优先考虑运行状态与恢复边界能否解释和验收，其次考虑集成与交付成本。本地探针增加了对这一组合的有限信心；ADK/Eino未做同场探针，不能由此推断它们更不稳定。

恢复契约有可解释的差异：LangGraph提供super-step与pending writes的保存契约；Eino的该版本图运行以中断保存为主要checkpoint路径，store需实现，恢复需保持图与调用配置一致；ADK resume文档对工具重复、自定义Agent和开发入口给出限制，不能直接等同于所有2.x图的崩溃恢复。选型应验收实际使用路径。

如果ADK Workflow已覆盖目标流程、恢复与升级验收通过，而且统一session/eval减少工程成本，应优先复用ADK。Go硬约束下，若Eino的目标存储与协议验收通过，应优先Eino。没有特殊拓扑时，LangChain可使用相同底层恢复能力，减少起步代码。推荐是可以被这些证据改变的工程决策。[S06](#source-s06)、[S19](#source-s19)、[S21](#source-s21)、[S27](#source-s27)、[S28](#source-s28)、[S73](#source-s73)。


## 比较方法与评分矩阵

### 如何解释分数

分数衡量该项能力的**工程便利程度**。先确认机制或维护中的集成，再看覆盖范围，最后列应用必须完成的工作。数字为本报告的工程判断，引用作者没有给框架这些分数。一个分差不能解释成20%的量化优势。


| 分值 | 含义 |
| --- | --- |
| 5 | 有直接且可组合的常用机制，该项额外建设较少 |
| 4 | 有可复用实现路径，仍有配置、适配或使用限制 |
| 3 | 有基础机制或集成路径，需要明显的应用组合 |
| 2 | 主要由应用或基础设施负责，专门支持有限 |
| 1 | 已确认主要能力有明显缺口；本版不因未找到文档而给1分 |
| U | 证据不足或必须同场实测；不是0分，也不代表不支持 |


N 表示框架或同项目SDK；E 表示额外包、协议SDK或服务；A 表示应用自建或治理。`4N+E`表示原生机制加扩展，`2A`表示主要应用责任。E不一定收费，N也需要配置。

证据分为：D（官方文档/源码）、T（局部实测）、U（待验证）。每个比较点给出对应来源与验收方法；完整测试状态集中列在代码章。配置合理并不证明生产安全，接口存在并不证明性能达标。

本版共16类64项。不计算无场景总分；权限、业务正确性等硬约束不能靠其他高分抵消。计算项目权重时还要防止重复计算：checkpoint与短期记忆、流程控制与多Agent、streaming与UI交互之间有关联。

### 常用术语

- **Checkpoint / state / run**：分别指执行记录、运行状态和一次任务；checkpoint保存了什么、何时保存，要以具体实现为准。
- **MCP（Model Context Protocol）/ SDK（Software Development Kit）**：前者用于模型应用接入工具和资源，后者是开发接口与库；接口兼容需按版本确认。
- **HITL（Human-in-the-loop）/ AI2UI**：前者是运行中由人补充或确认，后者在本文泛指Agent与界面交互；A2UI是其中一种具体界面协议。
- **RAG（Retrieval-augmented generation）/ tracing / provider**：分别是检索后生成、记录调用链、具体模型供应商或适配实现。
- **P95 / RSS / GIL**：分别是95%样本不超过的时延、进程驻留内存、CPython解释器锁；三者不能互相替代评价系统性能。
- **RPO / RTO**：分别表示故障恢复可接受的数据损失时间范围、恢复服务所需时间目标。

### 完整矩阵

按编号跳转即可查看定义、各框架分析、引用及验证办法。相同底层能力使用相同分数；高层入口与任意复杂图的控制能力仍分开比较。


#### A 开发体验


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [A1 简单 Agent 的起步成本](#criterion-a1) | 5N | 3N | 4N | 4N |
| [A2 数据类型与输入校验](#criterion-a2) | 4N | 4N | 4N | 4N |
| [A3 扩展与拦截点](#criterion-a3) | 5N | 4N | 4N | 4N |
| [A4 业务代码与框架解耦](#criterion-a4) | 3A | 3A | 3A | 3A |


#### B 模型与工具接入


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [B1 模型供应商与本地模型](#criterion-b1) | 4E | 4E | 4N+E | 4E |
| [B2 Structured output](#criterion-b2) | 5N+E | 4E+A | 4N+E | U |
| [B3 MCP 接入](#criterion-b3) | 4E | 4E | 4N+E | 4E |
| [B4 普通 API / OpenAPI 接入](#criterion-b4) | 3E+A | 3E+A | 4N+E | 3E+A |


#### C 流程控制


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [C1 分支、循环与确定性步骤](#criterion-c1) | 3N+E | 5N | 5N | 5N |
| [C2 并行执行与结果合并](#criterion-c2) | 3N+E | 5N | 4N | 4N |
| [C3 多 Agent 分工](#criterion-c3) | 4N+E | 5N | 5N | 4N |
| [C4 Agent 之间的上下文隔离](#criterion-c4) | 4A+E | 4N+A | 4N+A | 4N+A |


#### D 状态与恢复


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [D1 Checkpoint 持久化](#criterion-d1) | 5N+E | 5N+E | 4N+E | 3N+A |
| [D2 崩溃重放与副作用防重](#criterion-d2) | 3N+A | 3N+A | 3N+A | 2A |
| [D3 Human-in-the-loop](#criterion-d3) | 5N+E | 5N+E | 4N | 4N+A |
| [D4 执行历史、回放与版本升级](#criterion-d4) | 4N+A | 4N+A | 3N+A | 3N+A |


#### E 用户交互


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [E1 Streaming 与自定义事件](#criterion-e1) | 5N | 5N | 4N | 4N |
| [E2 动态表单与 Generative UI](#criterion-e2) | 4E+A | 4N+E+A | 4N+E+A | 4E+A |
| [E3 前端操作与受控页面跳转](#criterion-e3) | 3E+A | 3E+A | 3E+A | 3E+A |
| [E4 断线重连与 UI 状态恢复](#criterion-e4) | 3N+A | 3N+A | 2A | 2A |


#### F 权限与安全


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [F1 身份认证与工具授权](#criterion-f1) | 3N+A | 3A | 3N+A | 3N+A |
| [F2 多租户数据隔离](#criterion-f2) | 2A | 2A | 2A | 2A |
| [F3 Secrets 与敏感数据](#criterion-f3) | 3N+A | 3A | 3N+A | 3A |
| [F4 Prompt injection 与代码执行隔离](#criterion-f4) | 2A+E | 2A+E | 2A+E | 2A+E |


#### G 运行控制


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [G1 异步 I/O](#criterion-g1) | 4N | 4N | 4N | 4N |
| [G2 重试、超时与失败处理](#criterion-g2) | 4N+A | 4N+A | 3N+A | 3N+A |
| [G3 取消、暂停与后台任务](#criterion-g3) | 4N+A | 4N+A | 4N+A | 4N+A |
| [G4 配额、公平调度与背压](#criterion-g4) | 2A | 2A | 2A | 2A |


#### H 测试与观测


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [H1 Tracing 与执行排错](#criterion-h1) | 4E | 4E | 4N+E | 4E |
| [H2 自动化质量评测](#criterion-h2) | 4E | 4E | 4N+E | 3A+E |
| [H3 单元测试与故障注入](#criterion-h3) | 4N+A | 4N+A | 4N+A | 4N+A |
| [H4 业务指标与审计](#criterion-h4) | 3E+A | 3E+A | 3N+E+A | 3E+A |


#### I 部署与存储


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [I1 私有化与离线运行](#criterion-i1) | 4N+A | 4N+A | 4N+A | 4N+A |
| [I2 持久化后端与数据库](#criterion-i2) | 4E | 4E | 4N+E | 3A+E |
| [I3 多副本与高可用](#criterion-i3) | 3N+A+E | 3N+A+E | 3N+A+E | 3N+A |
| [I4 语言、运行时与交付形态](#criterion-i4) | 4E | 4N+E | 4N+E | 4N |


#### J 维护与生态


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [J1 升级兼容性](#criterion-j1) | 3N+A | 3N+A | 3N+A | 3N+A |
| [J2 文档与问题定位材料](#criterion-j2) | 3N | 3N | 3N | 3N |
| [J3 维护活跃度与问题响应](#criterion-j3) | U | U | U | U |
| [J4 依赖与供应链治理](#criterion-j4) | 3A | 3A | 3A | 3A |


#### K 成本与退出


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [K1 开源许可证](#criterion-k1) | 4N | 4N | 4N | 4N |
| [K2 商业平台依赖](#criterion-k2) | 3E+A | 3E+A | 3N+E+A | 3N+E+A |
| [K3 Token 与调用预算](#criterion-k3) | 4N+A | 4N+A | 4N+A | 4N+A |
| [K4 更换框架与数据迁移](#criterion-k4) | 3A | 3A | 3A | 3A |


#### L 性能实测


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [L1 相同工作负载下的时延与吞吐](#criterion-l1) | U | U | U | U |
| [L2 内存、CPU与启动开销](#criterion-l2) | U | U | U | U |
| [L3 长期运行与状态增长](#criterion-l3) | U | U | U | U |
| [L4 模型效果与系统成功率](#criterion-l4) | U | U | U | U |


#### M 记忆与知识


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [M1 会话历史与短期记忆](#criterion-m1) | 5N+E | 5N+E | 4N+E | 3N+A |
| [M2 跨会话长期记忆](#criterion-m2) | 4E+A | 4N+E+A | 4N+E+A | 3E+A |
| [M3 RAG 数据处理与检索](#criterion-m3) | 5E | 4E+A | 3N+E | 4E |
| [M4 Context 压缩与摘要](#criterion-m4) | 4N | 4E+A | 4N | 4N |


#### N 扩展交互与协作


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [N1 多模态输入输出](#criterion-n1) | 4N+E | 4E+A | 4N+E | 4N+E |
| [N2 实时语音与打断](#criterion-n2) | U | U | 4N+E | U |
| [N3 跨服务 Agent 协作 / A2A](#criterion-n3) | 3E+A | 3E+A | 4E | 3E+A |
| [N4 Skills 与按需加载能力](#criterion-n4) | 3E+A | 3E+A | 4N+E | 4N |


#### O 发布与持续运行


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [O1 Prompt、模型与配置版本](#criterion-o1) | 3A | 3A | 3A | 3A |
| [O2 CI/CD、灰度发布与回滚](#criterion-o2) | 2A+E | 2A+E | 2A+E | 2A+E |
| [O3 定时任务与外部事件触发](#criterion-o3) | 2A+E | 2A+E | 2A+E | 2A+E |
| [O4 长时间等待与优雅退出](#criterion-o4) | 3N+A | 3N+A | 3N+A | 3N+A |


#### P 数据与运行资产


| 比较点 | LangChain | LangGraph | Google ADK | Eino |
| --- | --- | --- | --- | --- |
| [P1 文件、报告与生成物管理](#criterion-p1) | 3E+A | 3E+A | 4N+E | 3E+A |
| [P2 数据保留、脱敏与删除](#criterion-p2) | 2A | 2A | 2A | 2A |
| [P3 备份、灾难恢复与RPO/RTO](#criterion-p3) | 2A | 2A | 2A | 2A |
| [P4 工具目录、schema与协议版本](#criterion-p4) | 3A+E | 3A+E | 3A+E | 3A+E |


## 生命周期能力分析

本章按工程主题展开。每个评分项的验收方法均为建议执行的办法；只有代码章标为实测的局部行为已经执行。


### A 开发体验

先看开发者如何写代码和定位错误。简单Agent的起步成本，与复杂系统的可控制程度，应分别比较。

**对选型的影响：** 普通循环优先LangChain；代码中的业务函数在四种框架中都应独立于运行时。


#### A1 简单 Agent 的起步成本

完成一次模型调用、一次工具调用，并拿到最终回答，需要搭建多少基础代码。


- **LangChain · 5N：** create_agent 封装常见模型—工具循环，简单任务代码少；复杂流程仍需理解运行机制。

- **LangGraph · 3N：** 通常要先定义 state、node、edge；起步代码较多，换来对流程的直接控制。

- **Google ADK · 4N：** Agent、Runner 和工具定义形成统一入口；先理解 session 与 event 才容易排查运行问题。

- **Eino · 4N：** ChatModelAgent 和 Go 工具接口可快速组合；泛型、错误处理使代码比 Python 示例显式。


依据：[S04](#source-s04)、[S05](#source-s05)、[S19](#source-s19)、[S27](#source-s27)。


**建议验证：** 由熟悉各语言的开发者完成同一小任务，分别记录开发与排错时间，不能只数代码行。


**代码与范围：** [C01](#code-c01)–[C04](#code-c04)。


#### A2 数据类型与输入校验

是否能提前发现字段缺失、类型错误；模型输出是否还需在运行时验证。


- **LangChain · 4N：** 工具参数和结构化输出可用类型定义与 Pydantic；类型正确仍不代表业务含义正确。

- **LangGraph · 4N：** state 可用 TypedDict/Pydantic 等描述；TypedDict 本身不会替所有节点做运行时校验。

- **Google ADK · 4N：** Python 的模型和工具 schema 提供结构约束，外部输入仍需业务校验。

- **Eino · 4N：** Go 泛型和 struct 可在编译期发现接口不匹配；JSON 与模型生成内容仍需运行时校验。


依据：[S40](#source-s40)、[S41](#source-s41)、[S42](#source-s42)、[S43](#source-s43)。


**建议验证：** 分别提交缺字段、错误类型、越界数值和额外字段，观察拒绝位置。


**代码与范围：** [C02](#code-c02)/[C04](#code-c04)/[C05](#code-c05)。


#### A3 扩展与拦截点

能否在模型、工具调用前后统一插入校验、日志或替换逻辑。


- **LangChain · 5N：** middleware 直接覆盖常见 agent loop 环节，适合统一策略。

- **LangGraph · 4N：** 可用节点、包装器和 runtime context；通用策略放在哪个边界需团队约定。

- **Google ADK · 4N：** callbacks/plugins 提供扩展入口，应确认当前使用的 Agent/Workflow 路径都经过这些入口。

- **Eino · 4N：** callback 和 ADK middleware 可扩展；不同版本的 state 改写时机需要回归。


依据：[S40](#source-s40)、[S42](#source-s42)、[S44](#source-s44)、[S30](#source-s30)。


**建议验证：** 正常、重试、resume 和子 Agent 四条路径都必须经过同一策略。


**代码与范围：** [C05](#code-c05)；各框架挂接位置依所选 API 配置。


#### A4 业务代码与框架解耦

以后换框架或升级时，业务规则能保留多少。


- **LangChain · 3A：** 工具函数可以独立，但 middleware 与消息类型容易扩散到业务代码。

- **LangGraph · 3A：** 图节点可调用普通函数；state 和 checkpoint 格式仍会形成框架依赖。

- **Google ADK · 3A：** 可把业务实现置于普通函数中；若业务直接依赖 ToolContext/Session，迁移成本增加。

- **Eino · 3A：** 用普通 Go 接口和 context 包装业务逻辑较直接；compose/adk 类型仍应限制在接入层。


依据：[S04](#source-s04)、[S42](#source-s42)、[S44](#source-s44)、[S43](#source-s43)。


**建议验证：** 选一条业务规则，在不启动框架的测试里运行；再估算更换消息/状态类型需要改多少文件。


**代码与范围：** [C05](#code-c05) 是框架外的普通函数示例。


### B 模型与工具接入

模型、MCP与HTTP工具是最容易复用生态的地方，也最容易出现“聊天可用、工具调用不兼容”的情况。接口存在和目标组件通过测试是两层证据。

**对选型的影响：** 已有adapter满足模型与协议时优先复用；缺少目标能力会推翻其他维度的优势。


#### B1 模型供应商与本地模型

切换模型时能否复用接口，以及流式、tool calling 等能力是否一致。


- **LangChain · 4E：** 统一模型接口和 provider packages 可复用；每种模型能力仍不同。

- **LangGraph · 4E：** 可直接调用模型 SDK，或复用 LangChain provider packages；可复用接口，实际兼容范围仍需按模型验证。

- **Google ADK · 4N+E：** 支持多个模型接入路径；Google 模型之外的功能需按 adapter 验证。

- **Eino · 4E：** ChatModel 接口与 eino-ext 提供适配；必须核实所选模型的具体参数及事件支持。


依据：[S45](#source-s45)、[S05](#source-s05)、[S17](#source-s17)、[S31](#source-s31)。


**建议验证：** 对目标模型逐项测试工具调用、流式、usage、超时、错误码，而不只测试普通聊天。


**代码与范围：** [C01](#code-c01) 用本地 stub，仅证明工具循环，不证明真实模型兼容。


#### B2 Structured output

模型是否能按指定 schema 返回数据，失败后是否易于处理。


- **LangChain · 5N+E：** 提供 provider/tool 两类结构化策略及验证入口；底层模型支持条件仍影响结果。

- **LangGraph · 4E+A：** 节点可使用模型结构化接口并做显式验证；图的 state 类型不自动约束模型文本。

- **Google ADK · 4N+E：** LlmAgent 的结构化配置可用；同时使用 tools、schema 与具体模型时需要组合测试。

- **Eino · U：** Go 解码和工具 schema 能构成实现基础；尚未核对目标provider的原生schema约束、错误重试和tools组合，不作相对完整度评分。


依据：[S41](#source-s41)、[S45](#source-s45)、[S43](#source-s43)、[S57](#source-s57)。


**建议验证：** 测试错误 JSON、合法 JSON 但缺字段、超长输出、拒答，以及 tools+schema 同时开启。


**代码与范围：** [C02](#code-c02) 展示业务输入验证；不冒充模型 Structured output DEMO。


#### B3 MCP 接入

能否列出远端工具、调用工具，并传递调用上下文。


- **LangChain · 4E：** langchain-mcp-adapters 可把 MCP 工具接入 agent；连接生命周期要配置。

- **LangGraph · 4E：** 复用相同 adapter 或直接 SDK；不必自行实现协议，但需自己控制节点与上下文。

- **Google ADK · 4N+E：** 官方 MCP 工具路径存在；版本、transport 和用户凭据要逐项验证。

- **Eino · 4E：** eino-ext 有 MCP 适配；SDK 变体与 _meta 行为需对照实际依赖。


依据：[S10](#source-s10)、[S31](#source-s31)、[S58](#source-s58)。


**建议验证：** 测试 Streamable HTTP、工具清单刷新、重连、取消、错误返回、每请求身份，不能只看 tools/list 成功。


#### B4 普通 API / OpenAPI 接入

已有 HTTP API 转成工具，需要多少手工描述和业务适配。


- **LangChain · 3E+A：** 可以把函数/HTTP 调用包装成工具；自动导入能力要按集成包评估。

- **LangGraph · 3E+A：** 图可调用任意 HTTP 客户端；本身不承担 OpenAPI 文档治理。

- **Google ADK · 4N+E：** 有官方 OpenAPI 工具路径，可减少基础描述工作；认证及响应语义仍要验证。

- **Eino · 3E+A：** Go 函数封装工具直接；声明导入、分页和风险审核通常仍由应用承担。


依据：[S10](#source-s10)、[S42](#source-s42)、[S59](#source-s59)、[S43](#source-s43)。


**建议验证：** 导入带分页、认证、枚举、oneOf 的同一 API，检查 schema 保真和错误表达。


**代码与范围：** [C01](#code-c01) 的普通函数工具仅展示接入入口。


### C 流程控制

流程控制决定哪些步骤必须执行、并行结果如何合并、子Agent看到哪些信息。多Agent数量不直接代表质量。

**对选型的影响：** 显式复杂流程推荐LangGraph；ADK Workflow和Eino compose同样应进入备选验证。


#### C1 分支、循环与确定性步骤

哪些步骤必须做、做完走哪一条路，能否在代码中明确表达。


- **LangChain · 3N+E：** 常见 agent loop 已封装；任意复杂业务拓扑通常要进入 LangGraph。

- **LangGraph · 5N：** StateGraph 直接定义节点和边，便于审查分支和终止条件。

- **Google ADK · 5N：** 2.x Workflow 已有显式图，不能按早期版本认定其没有图编排。

- **Eino · 5N：** compose Graph/Workflow 可以直接表达确定性步骤，适合与 Go 业务函数组合。


依据：[S40](#source-s40)、[S42](#source-s42)、[S19](#source-s19)、[S60](#source-s60)。


**建议验证：** 检查模型给出错误建议时，强制校验步骤仍不会被跳过。


**代码与范围：** [C02](#code-c02)/[C03](#code-c03)/[C04](#code-c04)。


#### C2 并行执行与结果合并

多个步骤能否同时运行；写同一份状态时冲突怎么处理。


- **LangChain · 3N+E：** 工具可以并行，复杂 fan-out/fan-in 更适合下沉到图。

- **LangGraph · 5N：** 并行节点与 reducer 能明确合并规则；错误 reducer 仍可能覆盖结果。

- **Google ADK · 4N：** Parallel Agent 和 graph 路径可表达并行；共享状态及合并规则要明确。

- **Eino · 4N：** 图分支和并行 Agent 可用；共享对象仍须遵守 Go 并发安全约束。


依据：[S42](#source-s42)、[S19](#source-s19)、[S27](#source-s27)、[S60](#source-s60)。


**建议验证：** 让两个分支同时写状态，再让其中一个失败，检查结果与重试行为。


**代码与范围：** [C08](#code-c08) 的并发任务实验不是单图 fan-in 验证。


#### C3 多 Agent 分工

能否按角色拆分任务，并控制交接、子任务生命周期。


- **LangChain · 4N+E：** 提供多 Agent 组合模式；多角色不自动提高质量，要衡量额外调用。

- **LangGraph · 5N：** 子图可明确分工、状态边界与返回路径，控制细但需要设计。

- **Google ADK · 5N：** Agent tree、工作流及协作能力是主要设计内容，适合统一 Runner 管理。

- **Eino · 4N：** ADK 有子 Agent、AgentTool 等路径；应按所选模式验证消息交接。


依据：[S46](#source-s46)、[S42](#source-s42)、[S19](#source-s19)、[S27](#source-s27)。


**建议验证：** 同一问题对比单 Agent 与多 Agent 的成功率、token 和时延，避免只展示角色数量。


#### C4 Agent 之间的上下文隔离

一个子 Agent 是否只看到它需要的信息，能否避免历史不断膨胀。


- **LangChain · 4A+E：** 可显式构造子 Agent 输入；不能默认把所有 history 原样转发。 [S46](#source-s46)

- **LangGraph · 4N+A：** 子图 state 和输入映射让信息边界显式；是否泄露共享state仍取决于应用输入与授权设计。 [S42](#source-s42)

- **Google ADK · 4N+A：** 可通过 session、state 和子 Agent 输入策略控制；要区分共享和局部信息。 [S22](#source-s22)

- **Eino · 4N+A：** AgentTool默认只接收模型生成的请求参数，完整history需要显式启用；特定Workflow Agent会共享上下文，应按协作模式选择。 [S72](#source-s72)、[S67](#source-s67)


依据：[S46](#source-s46)、[S42](#source-s42)、[S22](#source-s22)、[S67](#source-s67)、[S72](#source-s72)。


**建议验证：** 给一个子 Agent 填入仅它可见的标记，断言其他子 Agent 的模型输入中没有该标记。


**代码与范围：** [C05](#code-c05) 展示身份校验；不代替模型消息隔离测试。


### D 状态与恢复

运行状态保存、用户等待、崩溃重试与升级恢复应分别核对。外部API成功但运行记录尚未提交，是所有路线都要处理的窗口。

**对选型的影响：** 细粒度恢复是LangGraph的主要推荐理由；业务幂等、防重和对账仍需单独设计。


#### D1 Checkpoint 持久化

进程退出以后，是否还能读回执行状态；何时写入存储。


- **LangChain · 5N+E：** create_agent 依赖 LangGraph checkpointer，具备持久化基础；配置内存 saver 不算持久。 [S04](#source-s04)、[S06](#source-s06)

- **LangGraph · 5N+E：** super-step 与 pending writes 的保存契约明确，可接持久 saver。 [S06](#source-s06)

- **Google ADK · 4N+E：** Session/Event与resume提供恢复路径；官方文档对工具重复、自定义Agent、Web/CLI有明确限制。2.x Workflow组合未在本次验证。 [S21](#source-s21)

- **Eino · 3N+A：** 有中断保存与CheckPointStore，store由使用者实现；v0.9.21普通图运行不是默认每个完成节点都持久保存。中断恢复不等于任意强杀后的逐步恢复。 [S28](#source-s28)、[S73](#source-s73)


依据：[S04](#source-s04)、[S06](#source-s06)、[S21](#source-s21)、[S28](#source-s28)、[S73](#source-s73)。


**建议验证：** 分别在正常步骤后、人工等待中、工具调用中强杀，核对最后可恢复位置。


**代码与范围：** [C07](#code-c07)：真实 LangGraph 持久恢复代码与原始结果。


#### D2 崩溃重放与副作用防重

恢复会重复哪些代码，能否避免重复扣款、发消息或执行操作。


- **LangChain · 3N+A：** 继承底层恢复机制；外部副作用仍需要业务幂等。

- **LangGraph · 3N+A：** 重放位置有明确语义；工具成功而 checkpoint 未提交的窗口仍需下游幂等。

- **Google ADK · 3N+A：** 官方 resume 明确工具可能运行多次，应自行避免重复副作用。

- **Eino · 2A：** 中断类型影响重入；外部操作结果和 checkpoint 不天然处于同一事务。


依据：[S07](#source-s07)、[S21](#source-s21)、[S28](#source-s28)。


**建议验证：** 在远端提交后、状态提交前终止进程；必须能查询结果、防重或进入明确的不确定状态。


**代码与范围：** [C07](#code-c07)：effect_attempt=2，但模拟下游唯一操作只提交1次。


#### D3 Human-in-the-loop

中途请求人补充、修改或批准，之后能否继续。


- **LangChain · 5N+E：** HumanInTheLoopMiddleware 适合工具审批和编辑；完整恢复仍需 durable saver。

- **LangGraph · 5N+E：** interrupt/Command 可传结构化数据，适合多字段和业务交互。

- **Google ADK · 4N：** RequestInput 与 confirmation 提供交互入口；API/语言之间恢复细节不完全相同。

- **Eino · 4N+A：** 支持定向中断和带数据恢复；交互记录、有效期与 renderer 需要应用维护。


依据：[S61](#source-s61)、[S07](#source-s07)、[S20](#source-s20)、[S27](#source-s27)。


**建议验证：** 测试批准、拒绝、修改、多中断、超时，以及刷新页面后继续。


**代码与范围：** [C02](#code-c02)/[C03](#code-c03)/[C07](#code-c07)。


#### D4 执行历史、回放与版本升级

能否查看过去状态；旧任务能否在新代码下恢复。


- **LangChain · 4N+A：** 可用底层状态历史，但业务版本兼容仍自行管理。

- **LangGraph · 4N+A：** 提供历史与 time travel；回放不撤销真实外部操作，也不保证任意改图兼容。

- **Google ADK · 3N+A：** 有 session/event 历史；resume 文档对停止后修改工作流有明确限制。

- **Eino · 3N+A：** 有状态序列化和迁移相关能力；类型、图结构及 middleware 语义变动要回归。


依据：[S06](#source-s06)、[S21](#source-s21)、[S30](#source-s30)、[S74](#source-s74)。


**建议验证：** 用旧版本生成挂起任务，再升级节点/schema，验证兼容、迁移或明确拒绝。


**代码与范围：** [C07](#code-c07) 是同版本恢复，不是跨版本测试。


### E 用户交互

交互既包括文字流，也包括多字段表单、图表、既有页面和前端动作。恢复后能继续执行，不等于浏览器界面已经恢复。

**对选型的影响：** 复杂交互推荐图编排加UI协议；仅有固定表单时，高层Agent入口也可满足需求。


#### E1 Streaming 与自定义事件

能否逐步显示文本、进度、状态和工具执行结果。


- **LangChain · 5N：** Agent 可流式输出消息与状态，需前端适配具体事件格式。

- **LangGraph · 5N：** 提供多类流式事件，便于把图状态与业务进度分开。

- **Google ADK · 4N：** Runner/Event 提供流式路径；要定义用户可见与内部诊断事件的边界。

- **Eino · 4N：** StreamReader 与 AgentEvent 提供输出机制；消费者需要处理结束、错误和背压。


依据：[S08](#source-s08)、[S19](#source-s19)、[S27](#source-s27)、[S60](#source-s60)、[S74](#source-s74)。


**建议验证：** 测试 token、progress、tool error、取消与断连；进度事件不能冒充模型首 token。


**代码与范围：** [C08](#code-c08) 涉及运行，不证明前端 Streaming 已接通。


#### E2 动态表单与 Generative UI

Agent 能否要求填写多个字段、展示图表和可交互组件。


- **LangChain · 4E+A：** 可通过 UI adapter 和工具/交互载荷生成组件；不是 create_agent 自带网页。

- **LangGraph · 4N+E+A：** 结构化 interrupt 和自定义事件适合关联表单，renderer 与 catalog 另外实现。

- **Google ADK · 4N+E+A：** RequestInput 携带输入需求，可连接交互层；开发 UI 不等于完整生产 UI。

- **Eino · 4E+A：** 已有 A2UI 示例，可复用协议思路；实际组件与校验仍有工作量。


依据：[S33](#source-s33)、[S35](#source-s35)、[S20](#source-s20)、[S32](#source-s32)。


**建议验证：** 同一表单包含日期、资源树、联动字段和编辑计划，测试服务端校验与版本兼容。


**代码与范围：** [C02](#code-c02) 是结构化输入；[C05](#code-c05) 是应用事件校验，无 renderer。


#### E3 前端操作与受控页面跳转

能否打开详情页、更新筛选条件，且不能执行任意前端代码。


- **LangChain · 3E+A：** 可接前端工具事件；页面路由和允许操作由宿主管理。

- **LangGraph · 3E+A：** 图输出 UI intent，再由宿主执行；图不应持有任意 DOM 权限。

- **Google ADK · 3E+A：** 工具或事件可表示 UI intent；认证与页面执行策略仍在宿主。

- **Eino · 3E+A：** A2UI/custom event 可承载请求；宿主决定允许的操作和参数。


依据：[S35](#source-s35)、[S33](#source-s33)、[S36](#source-s36)。


**建议验证：** 允许 open_detail(resource_id)，拒绝任意 URL、JavaScript 和未经授权资源。


**代码与范围：** [C05](#code-c05)：open_detail 与 submit_query 白名单。


#### E4 断线重连与 UI 状态恢复

浏览器刷新、换设备后，能否恢复等待中的表单和任务进度。


- **LangChain · 3N+A：** 执行状态可持久，但 UI snapshot、事件游标和重复事件处理不是高层 Agent 自动提供。

- **LangGraph · 3N+A：** 可据 checkpoint 重建业务状态；事件持久日志与前端一致性仍要补齐。

- **Google ADK · 2A：** session/event 可以作为基础；须检查 SSE 断连是否会取消当前运行。

- **Eino · 2A：** 从 checkpoint 重建等待内容可行；surface 快照与事件恢复需应用设计。


依据：[S06](#source-s06)、[S18](#source-s18)、[S27](#source-s27)、[S35](#source-s35)、[S74](#source-s74)。


**建议验证：** 断连后重发同一事件、恢复过期游标和多标签页提交，不能出现重复审批。


**代码与范围：** [C07](#code-c07) 只证明后端恢复；本版未实现可回放 SSE。


### F 权限与安全

身份、权限、秘密数据与不可信内容必须在实际执行入口检查。这里的低分表示应用责任较多，不是已发现框架漏洞。

**对选型的影响：** 四者都需完整授权与数据治理；不能以某框架的总分代替越权测试。


#### F1 身份认证与工具授权

谁可以使用哪个工具，是否会在每次实际执行前检查。


- **LangChain · 3N+A：** middleware 有执行拦截点；真实身份及授权策略由应用提供。

- **LangGraph · 3A：** 可放独立授权节点或包装工具；thread_id 本身不是登录身份。

- **Google ADK · 3N+A：** callback/plugin 可检查调用；不能把 session user_id 当成已认证身份。

- **Eino · 3N+A：** context/middleware 可传受信身份；客户端 _meta 字段本身不可信。


依据：[S40](#source-s40)、[S24](#source-s24)、[S37](#source-s37)、[S27](#source-s27)。


**建议验证：** 伪造身份、绕过UI、从resume/子Agent入口调用同一工具时都应检查。


**代码与范围：** [C05](#code-c05)。


#### F2 多租户数据隔离

会话、记忆、缓存、文件和历史是否可能被其他租户读取。


- **LangChain · 2A：** 需要在所有存储与工具入口加入租户约束；框架不是租户隔离产品。

- **LangGraph · 2A：** namespace/thread 可组织数据，不能自动阻止使用别人 ID 访问。

- **Google ADK · 2A：** app/user/session 提供分组，不替代服务端认证和完整访问控制。

- **Eino · 2A：** 需要严格的上下文与缓存键；goroutine 并发安全不等于租户隔离。


依据：[S06](#source-s06)、[S22](#source-s22)、[S27](#source-s27)、[S24](#source-s24)。


**建议验证：** 覆盖 get/list/history/export/delete/trace；两个租户使用相同本地用户ID也必须隔离。


**代码与范围：** [C05](#code-c05)/[C07](#code-c07)；后者演示绕过接入层可直接读 saver。


#### F3 Secrets 与敏感数据

密钥、用户数据是否会进入 prompt、checkpoint 或 tracing。


- **LangChain · 3N+A：** 可用 middleware 做脱敏，但所有回调、模型和工具日志都要检查。

- **LangGraph · 3A：** state 是应用定义的；不把明文secret存进去才是关键，持久化不会自动消除泄露。

- **Google ADK · 3N+A：** 提供认证工具和安全实践；日志、session和模型输入仍需数据策略。

- **Eino · 3A：** Go 字符串、HTTP库、日志仍可能持有副本；语言不能保证密钥绝无残留。


依据：[S40](#source-s40)、[S24](#source-s24)、[S06](#source-s06)、[S31](#source-s31)。


**建议验证：** 使用唯一假密钥跑完整流程，再搜索日志、checkpoint和trace，不用真实secret做测试。


#### F4 Prompt injection 与代码执行隔离

不可信文档能否诱使 Agent 越权；执行代码时是否有 sandbox。


- **LangChain · 2A+E：** guardrail与工具限制可组合；提示词防护不能替代权限与sandbox。

- **LangGraph · 2A+E：** 可明确控制每条执行路径；图结构本身不会消除注入。

- **Google ADK · 2A+E：** 官方有安全实践与callback入口，可组合工具限制；本次无证据证明其注入防御或代码隔离强于其他框架。

- **Eino · 2A+E：** 可在工具层强制检查并接sandbox；普通Go进程不是安全沙箱。


依据：[S24](#source-s24)、[S37](#source-s37)、[S40](#source-s40)、[S27](#source-s27)。


**建议验证：** 恶意检索文本、工具描述、文件路径和出站URL都纳入攻击测试；记录是否触发越权副作用。


**代码与范围：** [C05](#code-c05) 仅示范动作白名单，不是完整注入防御。


### G 运行控制

任务怎样等待、重试、取消和排队，决定系统在负载和错误下的行为。异步能力与生产容量分开比较。

**对选型的影响：** 先用非阻塞I/O和限额设计，再测瓶颈；Go和Python各自的机制不能替代负载测试。


#### G1 异步 I/O

等待模型或API时，能否继续处理别的任务。


- **LangChain · 4N：** ainvoke/astream 等异步接口可用，底层同步调用仍可能拖慢任务。

- **LangGraph · 4N：** 异步图节点适合I/O编排，必须避免在事件循环里做长时间同步计算。

- **Google ADK · 4N：** run_async 等运行方式支持异步；具体工具实现决定是否阻塞。

- **Eino · 4N：** Go context/goroutine 和框架运行接口适合并发I/O，仍需限额与取消传播。


依据：[S08](#source-s08)、[S39](#source-s39)、[S21](#source-s21)、[S27](#source-s27)、[S64](#source-s64)。


**建议验证：** 用相同I/O延迟、连接池和并发数测试，分别记录等待与CPU时间。


**代码与范围：** [C08](#code-c08)。


#### G2 重试、超时与失败处理

暂时错误能否重试；不可重试错误是否立即结束。


- **LangChain · 4N+A：** middleware可覆盖重试/fallback；仍需避免底层SDK和上层重复重试放大请求。

- **LangGraph · 4N+A：** 节点RetryPolicy等让失败边界明确；业务错误分类和远端幂等仍应用负责。

- **Google ADK · 3N+A：** 可用运行配置、回调与工具处理错误；需核实失败发生在哪层。

- **Eino · 3N+A：** 可以组合context deadline、节点和工具错误处理；不要只把所有error统一重试。


依据：[S40](#source-s40)、[S42](#source-s42)、[S44](#source-s44)、[S60](#source-s60)。


**建议验证：** 对429、连接中断、参数错误、权限拒绝分开断言；限制总尝试次数和总deadline。


**代码与范围：** [C07](#code-c07) 提供崩溃重试边界，不模拟所有错误类型。


#### G3 取消、暂停与后台任务

用户点取消或断开连接时，正在执行与排队的任务怎么处理。


- **LangChain · 4N+A：** 可利用底层运行机制，但后台任务生命周期仍需服务层定义。

- **LangGraph · 4N+A：** 任务取消与图状态可显式管理；实际远端操作是否已完成必须另查。

- **Google ADK · 4N+A：** 近期版本加入运行取消；官方server断连行为可能不符合后台任务需求。

- **Eino · 4N+A：** 主动中断及Cancel/TurnLoop路径可用；优雅取消与进程强杀是不同事件。


依据：[S18](#source-s18)、[S28](#source-s28)、[S08](#source-s08)、[S74](#source-s74)。


**建议验证：** 分别取消排队、模型生成、工具调用、人工等待；确认后续工具不再启动。


**代码与范围：** [C07](#code-c07) 展示强退，不等于优雅取消测试。


#### G4 配额、公平调度与背压

一个用户发很多任务时，是否会挤占全部资源。


- **LangChain · 2A：** 局部middleware限流可用，全局/租户公平队列仍要外部实现。

- **LangGraph · 2A：** 图内并行上限不等于跨进程配额与公平性。

- **Google ADK · 2A：** 运行预算并不能自动提供多租户队列调度。

- **Eino · 2A：** goroutine便宜也不能无限启动；共享限流账本与队列仍需设计。


依据：[S40](#source-s40)、[S42](#source-s42)、[S24](#source-s24)、[S27](#source-s27)。


**建议验证：** 一个租户占80%流量；验证其他租户等待上限，队列满时要可解释地拒绝或延后。


### H 测试与观测

观测帮助找到错误，测试帮助复现错误，质量评测帮助判断换模型后有没有退化，审计则回答谁批准和执行了操作。

**对选型的影响：** 希望开发与评测入口集中时优先ADK；其他框架可接外部评测与观测服务。


#### H1 Tracing 与执行排错

能否看到一次任务中模型、工具、子任务的输入输出与耗时。


- **LangChain · 4E：** LangSmith/Langfuse等已有接入路径；完整查看通常需要额外存储与界面。

- **LangGraph · 4E：** 图/节点事件易关联trace，选用观测后端另行部署。

- **Google ADK · 4N+E：** 官方logging/metrics/traces和集成可用；具体字段及隐私需配置。

- **Eino · 4E：** callback和Langfuse扩展存在；不能说Go侧必须从零手写观测协议。


依据：[S13](#source-s13)、[S12](#source-s12)、[S47](#source-s47)、[S31](#source-s31)。


**建议验证：** 一条请求跨模型、工具、resume后仍可关联；错误与敏感字段能正确处理。


#### H2 自动化质量评测

换模型/提示词后，能否发现回答和工具调用退化。


- **LangChain · 4E：** 可接评测服务/库；需要自己准备业务数据、评价准则和基线。

- **LangGraph · 4E：** 图状态和轨迹便于断言，效果评测依赖额外工具。

- **Google ADK · 4N+E：** 官方evaluation入口是明确优势；仍不能由框架自动判断业务答案正确。

- **Eino · 3A+E：** eino-ext 列有评测及优化扩展，可复用组件；未核实与 ADK 同等的一体化评测流程，不据此判定没有评测能力。


依据：[S11](#source-s11)、[S23](#source-s23)、[S31](#source-s31)。


**建议验证：** 同时评价最终答案、工具轨迹、错误拒绝、成本；不能仅用一个LLM judge总分。


**代码与范围：** [C01](#code-c01)/[C02](#code-c02) 是机制断言，不是回答质量评测。


#### H3 单元测试与故障注入

不用真实模型时，是否能重复验证业务行为。


- **LangChain · 4N+A：** 可替换模型和工具，离线模拟工具循环；副作用仍应隔离。

- **LangGraph · 4N+A：** 纯函数节点与可控state适合确定性测试、故障注入。

- **Google ADK · 4N+A：** 可测试工具、回调及Runner；具体测试对象要避免共享session污染。

- **Eino · 4N+A：** 普通Go函数、接口mock及race检测适合工程测试；模型效果另测。


依据：[S11](#source-s11)、[S42](#source-s42)、[S23](#source-s23)、[S60](#source-s60)。


**建议验证：** 固定模型stub，注入超时/异常/重放，要求多次执行结果一致。


**代码与范围：** [C01](#code-c01)/[C02](#code-c02)/[C05](#code-c05)/[C07](#code-c07)。


#### H4 业务指标与审计

能否回答成功率、成本、越权尝试、谁批准了操作。


- **LangChain · 3E+A：** usage和trace可作原料，成功率与合规审计要业务定义。

- **LangGraph · 3E+A：** 事件可统计节点结果；checkpoint不是不可修改的审计账本。

- **Google ADK · 3N+E+A：** 有metrics基础，业务审计保留/授权/完整性仍需独立设计。

- **Eino · 3E+A：** callback可埋点，审计责任与trace不能混为一份随意保留的日志。


依据：[S13](#source-s13)、[S06](#source-s06)、[S47](#source-s47)、[S31](#source-s31)。


**建议验证：** 把排队、模型首token、最终完成分开；审批人、工具参数摘要、结果需可追溯。


**代码与范围：** [C07](#code-c07) 的计数仅供实验，不是合规审计系统。


### I 部署与存储

部署形态、存储适配和多副本协调共同决定可运维性。共享数据库只能提供部分基础，并不自动实现整次run互斥。

**对选型的影响：** 运行时为硬约束时优先筛语言；其余路线以目标数据库和故障接管验收决定。


#### I1 私有化与离线运行

能否不依赖厂商托管服务部署，能否禁止非必要外联。


- **LangChain · 4N+A：** 可嵌入自建服务；模型、依赖和观测是否联网另行配置。

- **LangGraph · 4N+A：** 开源库可自行部署，不强制购买LangSmith平台；服务运维要自己承担。

- **Google ADK · 4N+A：** 有自托管部署路径，不等于必须使用Google Cloud；模型选择影响离线性。

- **Eino · 4N+A：** 可构建Go服务交付；依赖下载、模型和外部组件仍需离线准备。


依据：[S04](#source-s04)、[S05](#source-s05)、[S48](#source-s48)、[S31](#source-s31)。


**建议验证：** 断开公网后安装、启动、执行、恢复；抓取出站连接确认没有隐式依赖。


#### I2 持久化后端与数据库

有哪些可复用存储适配；维护责任和能力是否完整。


- **LangChain · 4E：** 使用底层LangGraph savers；不能把不同维护者的适配视为相同保证。

- **LangGraph · 4E：** PG/SQLite及MongoDB等路径存在，MySQL有独立维护者实现；需看并发及版本契约。

- **Google ADK · 4N+E：** DatabaseSessionService覆盖常见SQL数据库，需异步驱动与schema迁移。

- **Eino · 3A+E：** CheckpointStore易接已有存储，但历史、原子性与多副本控制需明确补齐。


依据：[S09](#source-s09)、[S15](#source-s15)、[S16](#source-s16)、[S22](#source-s22)、[S28](#source-s28)。


**建议验证：** 对目标数据库跑恢复、并发、历史清理和升级测试；不要只看写入一次成功。


**代码与范围：** [C07](#code-c07) 使用SQLite，不证明其他数据库已通过。


#### I3 多副本与高可用

增加副本后能否接管未完成任务，避免两个副本同时执行。


- **LangChain · 3N+A+E：** 共享持久层是基础，任务分发/租约等由服务或平台补齐。

- **LangGraph · 3N+A+E：** 可跨进程恢复，run单写者、抢占和故障接管仍需控制面。

- **Google ADK · 3N+A+E：** 数据库会话锁有帮助，但append_event行锁不等于整次run互斥。

- **Eino · 3N+A：** 共享store可跨实例resume，leader/lease/重复运行控制不由存储接口自动解决。


依据：[S06](#source-s06)、[S22](#source-s22)、[S27](#source-s27)。


**建议验证：** 两个副本竞争同一任务、旧副本暂停后恢复，检查是否发生重复外部操作。


**代码与范围：** [C07](#code-c07) 是串行新进程恢复，未证明分布式租约正确。


#### I4 语言、运行时与交付形态

有哪些语言实现；宿主需要什么运行环境。


- **LangChain · 4E：** 本表按Python实现评分；JS/TS另有实现，不假定API完全一致。

- **LangGraph · 4N+E：** Python及官方JS路线；Python包下限与CLI/扩展的要求应分别核对。

- **Google ADK · 4N+E：** 有多语言SDK；本表以Python为主，各语言功能须逐项确认。

- **Eino · 4N：** Go编译交付适合Go团队；CGO、CPU架构与依赖可能影响二进制可移植性。


依据：[S01](#source-s01)、[S02](#source-s02)、[S14](#source-s14)、[S17](#source-s17)、[S25](#source-s25)、[S26](#source-s26)、[S65](#source-s65)。


**建议验证：** 在目标OS/CPU和容器中离线构建启动；不能用“支持容器”跳过兼容验证。


**代码与范围：** [C04](#code-c04) 附go.mod；未在本机编译。


### J 维护与生态

维护成本来自升级、依赖组合、过时示例和问题响应。近期发布能证明有活动，不能证明未来维护承诺或修复SLA。

**对选型的影响：** 锁定版本与组件组合；没有采集响应统计前，不按社区印象淘汰候选。


#### J1 升级兼容性

框架更新后，旧代码、状态和正在等待的任务是否还能工作。


- **LangChain · 3N+A：** 需一起锁定core、provider、LangGraph及middleware，不能只升级一个包。

- **LangGraph · 3N+A：** 有状态与图契约文档，但没有同场跨版本恢复测试，不能据此判定升级兼容性优于其他框架。

- **Google ADK · 3N+A：** 2.x快速演进且发布记录含breaking change；session schema也可能需迁移。

- **Eino · 3N+A：** 0.x已有明确迁移说明，说明行为在变化；不要把版本号当兼容保证。


依据：[S03](#source-s03)、[S06](#source-s06)、[S18](#source-s18)、[S30](#source-s30)。


**建议验证：** 保存上一版运行样本，升级后恢复并对比工具轨迹和状态。


**代码与范围：** [C07](#code-c07) 是同版本；跨版本测试待执行。


#### J2 文档与问题定位材料

是否能找到概念、限制、API、完整示例，而不只是一段宣传介绍。


- **LangChain · 3N：** 概念和API材料齐全；新旧高层API混用时仍需留意文档版本。

- **LangGraph · 3N：** state/interrupt/checkpointer有明确说明；学习成本不等于文档缺失。

- **Google ADK · 3N：** 有开发、运行、评测文档；须分清旧Agent和2.x Workflow路线。

- **Eino · 3N：** 有中文/英文文档和例子；必须检查示例对应的Eino版本。


依据：[S04](#source-s04)、[S06](#source-s06)、[S19](#source-s19)、[S28](#source-s28)。


**建议验证：** 让未参与开发的人仅凭文档复现故障；记录过时示例和缺失信息，不以页面数量评分。


**代码与范围：** [C01](#code-c01)–[C04](#code-c04) 对比最小接入；不能据其推断总体学习工时。


#### J3 维护活跃度与问题响应

多久发布、多少人维护、问题多久首次回复和修复。


- **LangChain · U：** 有近期版本，但本次未取得完整issue/PR统计，不能给响应速度分。

- **LangGraph · U：** 有近期版本；monorepo中CLI/SDK发布不能都算作graph核心更新。

- **Google ADK · U：** 持续发布可确认，社区响应分布与企业支持SLA未测。

- **Eino · U：** 稳定版与alpha并行发布，不能据印象认定低活跃；响应速度未测。


依据：[S03](#source-s03)、[S18](#source-s18)、[S26](#source-s26)、[S62](#source-s62)。


**建议验证：** 固定90天窗口，区分release/commit/issue，报告中位数/P90和未回复比例；stars不代替维护质量。


#### J4 依赖与供应链治理

能否固定版本、追溯来源、扫描风险并及时更新。


- **LangChain · 3A：** 拆分provider包便于按需安装，也增加依赖组合管理工作。

- **LangGraph · 3A：** core/saver/SDK有独立版本，需固定兼容组合并审查序列化依赖。

- **Google ADK · 3A：** extras可以按需选择；不应把全部可选集成默认装入生产。

- **Eino · 3A：** go.mod/go.sum支持依赖管理；原生依赖与扩展仓库也要纳入扫描。


依据：[S02](#source-s02)、[S17](#source-s17)、[S31](#source-s31)。


**建议验证：** 生成SBOM、固定制品hash、查安全公告和许可证；本次未做全依赖漏洞审计。


### K 成本与退出

核心许可、商业平台、自建人力、模型调用和退出迁移共同构成成本。某个软件包免费不等于整个运行平台低成本。

**对选型的影响：** 按同等功能范围列费用与人力；退出方案先保留普通业务状态，再规划旧任务排空。


#### K1 开源许可证

框架核心是否允许目标使用方式；扩展和模型是否另有条款。


- **LangChain · 4N：** 核心MIT；第三方包、模型和托管平台条款分别审查。

- **LangGraph · 4N：** 核心MIT；不能把开源许可扩展到全部LangSmith产品。

- **Google ADK · 4N：** 核心Apache-2.0；Google Cloud服务条款单独计算。

- **Eino · 4N：** 核心Apache-2.0；企业自身分发与扩展依赖仍要逐项审查。


依据：[S01](#source-s01)、[S03](#source-s03)、[S17](#source-s17)、[S26](#source-s26)、[S63](#source-s63)。


**建议验证：** 交付物逐包许可证清单，由负责人员确认使用与分发条件。


#### K2 商业平台依赖

评测、监控、部署等完整体验是否依赖付费服务。


- **LangChain · 3E+A：** 核心可独立用；完整LangSmith自托管有商业要求，亦可接其他后端。

- **LangGraph · 3E+A：** 库不强制付费平台；选择Agent Server/平台功能应另查授权，不能默认为免费。

- **Google ADK · 3N+E+A：** 本地运行与eval路径存在，云托管和高级服务另计费。

- **Eino · 3N+E+A：** 库可自行部署；缺少或另接的工作台会转化为工程和运维成本。


依据：[S12](#source-s12)、[S13](#source-s13)、[S23](#source-s23)、[S48](#source-s48)、[S31](#source-s31)。


**建议验证：** 分别列软件费、基础设施费和自建人力；不把开源简单翻译成零成本。


#### K3 Token 与调用预算

能否限制迭代次数、工具次数、上下文和总费用。


- **LangChain · 4N+A：** middleware可限制调用并做摘要；预算币种、租户累计仍需应用管理。

- **LangGraph · 4N+A：** 可用state/条件边限制步骤；跨run预算要外部账本。

- **Google ADK · 4N+A：** 运行配置与上下文策略可控制部分调用；usage完整性随模型不同。

- **Eino · 4N+A：** 循环限制和中间件可控制调用；工具配额和货币成本需要自建统计。


依据：[S40](#source-s40)、[S42](#source-s42)、[S18](#source-s18)、[S30](#source-s30)。


**建议验证：** 构造无限规划倾向，确认达到上限会停止，且重试和resume不会绕过总预算。


**代码与范围：** [C05](#code-c05)的策略写法可复用，附件未实现计费账本。


#### K4 更换框架与数据迁移

以后更换框架，需要重写哪些东西，历史任务怎么处置。


- **LangChain · 3A：** 模型/工具抽象可保留一部分；middleware与运行状态需改写。

- **LangGraph · 3A：** 业务节点可能可复用；原生checkpoint不可直接交给其他框架继续执行。

- **Google ADK · 3A：** session/event可导出业务信息，但不能视为通用运行时快照。

- **Eino · 3A：** 业务Go接口可保留；checkpoint和Agent协作类型仍绑定Eino。


依据：[S06](#source-s06)、[S22](#source-s22)、[S28](#source-s28)。


**建议验证：** 抽取普通业务状态和工件，演练旧run排空；不要承诺跨框架无损热迁移。


**代码与范围：** [C05](#code-c05) 是可跨框架复用的业务策略例子。


### L 性能实测

吞吐、内存、长期增长和实际成功率必须用相同条件测量。现有短批次LangGraph实验只能解释局部机制。

**对选型的影响：** 保留U，不发布性能冠军；达到业务正确性要求后再比较资源效率。


#### L1 相同工作负载下的时延与吞吐

框架本身多花多少时间，而不是比较不同模型的快慢。


- **LangChain · U：** 没有同场实测，不按高层封装数量推断快慢。

- **LangGraph · U：** 已有局部合成负载结果，但不足以给四框架相对分。

- **Google ADK · U：** 没有同场实测，不能把SDK异步能力当作生产QPS。

- **Eino · U：** 没有同场实测，不能因Go语言就判定端到端更快。


依据：[S38](#source-s38)、[S39](#source-s39)。


**建议验证：** 同模型stub、节点数、持久化语义、数据量、硬件；测P50/P95/P99与开放到达率。


**代码与范围：** [C08](#code-c08)；不用于四框架性能排名。


#### L2 内存、CPU与启动开销

空闲和高负载分别占多少资源，何时成为瓶颈。


- **LangChain · U：** 需要实际依赖组合和并发状态测量。

- **LangGraph · U：** 局部进程RSS不能外推完整服务及数据库总预算。

- **Google ADK · U：** 加载的extras、模型客户端与事件历史影响资源占用。

- **Eino · U：** 需测真实Go程序、GC与工作集；二进制形式不等于内存一定更低。


依据：[S02](#source-s02)、[S17](#source-s17)、[S38](#source-s38)。


**建议验证：** 记录idle/peak RSS或cgroup、CPU秒、启动时间、连接数；包括所有子进程与sidecar。


**代码与范围：** [C08](#code-c08) 有局部采样，不是完整部署测量。


#### L3 长期运行与状态增长

运行几小时或几个月后，checkpoint、history和缓存是否持续膨胀。


- **LangChain · U：** 应测长对话、摘要与历史保留，不只短demo。

- **LangGraph · U：** checkpoint写入量与保留策略会影响数据库和恢复速度。

- **Google ADK · U：** session/event增长、压缩和清理行为需长时间验证。

- **Eino · U：** 内存缓存与持久store的历史保留由具体实现决定。


依据：[S06](#source-s06)、[S22](#source-s22)、[S28](#source-s28)、[S49](#source-s49)。


**建议验证：** 稳定负载至少数小时并做历史规模分档测试，测存储/任务增长量和清理后恢复。


#### L4 模型效果与系统成功率

相同问题下任务是否正确完成，代价与错误率如何。


- **LangChain · U：** 模型质量、prompt与工具设计共同决定，不能把简单API等同更高准确率。

- **LangGraph · U：** 流程控制可提高可预测性，但不能直接推出更高模型回答分。

- **Google ADK · U：** 评测入口完善不代表实际业务得分一定最高。

- **Eino · U：** 语言和框架不会自动改善模型理解；应使用相同数据和模型比较。


依据：[S23](#source-s23)、[S11](#source-s11)、[S45](#source-s45)。


**建议验证：** 固定数据集与模型版本，多次采样；人工复核关键错误，报告置信区间和成本。


**代码与范围：** [C01](#code-c01)为确定性stub，不是模型效果成绩。


### M 记忆与知识

短期会话历史、长期事实记忆、RAG和摘要承担不同职责。记忆能查到不等于内容正确，也不等于当前用户有权使用。

**对选型的影响：** 简单RAG可从LangChain起步；多阶段检索与验证用LangGraph组织，其他路线按组件匹配。


#### M1 会话历史与短期记忆

下一轮是否能接着上一轮交流，恢复后信息是否还在。


- **LangChain · 5N+E：** 短期记忆通过checkpointer持久化；截断策略影响可见历史。

- **LangGraph · 5N+E：** state/checkpointer可明确管理thread内历史；保留与压缩由应用选择。

- **Google ADK · 4N+E：** Session/Event管理对话历史；持久性取决于SessionService。

- **Eino · 3N+A：** Agent状态与store可组织历史，需要明确普通多轮与checkpoint的职责。


依据：[S50](#source-s50)、[S06](#source-s06)、[S22](#source-s22)、[S27](#source-s27)。


**建议验证：** 关闭进程后继续对话，检查事实、工具结果和挂起状态分别是否保留。


**代码与范围：** [C07](#code-c07)证明执行状态，不证明完整对话记忆产品。


#### M2 跨会话长期记忆

能否保存用户偏好或业务事实，并管理更新、删除和冲突。


- **LangChain · 4E+A：** 可接store/检索组件；哪些内容该记、何时失效需要业务策略。

- **LangGraph · 4N+E+A：** store与thread checkpoint分开，有利于区分长期事实和执行状态。

- **Google ADK · 4N+E+A：** MemoryService等提供路径；隐私、范围与错误记忆修正仍应用负责。

- **Eino · 3E+A：** 可接Retriever/Indexer等组件建立长期记忆，但语义治理需自行实现。


依据：[S09](#source-s09)、[S51](#source-s51)、[S43](#source-s43)。


**建议验证：** 跨会话读取、权限撤销、纠错与删除都应可测；不能把vector search等同记忆正确。


#### M3 RAG 数据处理与检索

文档加载、切分、embedding、检索和来源引用是否容易组合。


- **LangChain · 5E：** 可以复用专门的数据与检索集成；新版高层入口变化须核对实际包。

- **LangGraph · 4E+A：** 可编排检索步骤，但数据组件主要来自外部库。

- **Google ADK · 3N+E：** 可接检索工具/Memory等路径；目标数据源与搜索产品决定额外适配。

- **Eino · 4E：** Loader/Parser/Indexer/Retriever等接口覆盖数据链路，具体数据库在扩展中。


依据：[S52](#source-s52)、[S09](#source-s09)、[S51](#source-s51)、[S43](#source-s43)、[S31](#source-s31)。


**建议验证：** 同语料测召回、引用正确性、增量更新、权限过滤和无结果处理。


#### M4 Context 压缩与摘要

长对话是否会超出模型窗口，压缩后是否丢关键事实。


- **LangChain · 4N：** 有SummarizationMiddleware等入口；摘要质量仍须测试。

- **LangGraph · 4E+A：** 可显式设计裁剪/摘要节点或复用LangChain中间件。

- **Google ADK · 4N：** 有context compression配置；适用路径和模型成本应核对。

- **Eino · 4N：** 有Summarization/Reduction等中间件；升级时关注对state的修改语义。


依据：[S40](#source-s40)、[S49](#source-s49)、[S30](#source-s30)。


**建议验证：** 跨压缩保留约束、权限、资源ID和未完成计划；记录额外token与信息丢失。


**代码与范围：** [C07](#code-c07)不测上下文压缩；需要长对话fixture。


### N 扩展交互与协作

多模态、实时语音、跨服务Agent和Skills有不同协议及运行要求。普通streaming不能推导全部扩展能力。

**对选型的影响：** 受支持Live场景优先ADK；A2A与Skills的实验性状态及版本应单独控制。


#### N1 多模态输入输出

图片、音频、文件等能否进入模型与工具流程。


- **LangChain · 4N+E：** 标准消息及provider支持多模态，但不是每个模型都支持所有媒体。

- **LangGraph · 4E+A：** 图可传递媒体引用；解码、模型和前端能力由组件提供。

- **Google ADK · 4N+E：** 模型Content/Part及相关运行路径支持多模态；需核对模型与transport组合。

- **Eino · 4N+E：** 消息/模型扩展可接多模态；目标provider与消息格式需专门验证。


依据：[S45](#source-s45)、[S57](#source-s57)、[S43](#source-s43)。


**建议验证：** 分别测图片理解、文件引用、超大媒体、权限与保留；不把base64传入成功当理解成功。


#### N2 实时语音与打断

持续语音对话、用户插话、音视频同步是否有专门支持。


- **LangChain · U：** 普通token streaming不等于实时双向语音；本次未验证指定组合。

- **LangGraph · U：** 可编排相关服务，但本次未核实可直接复用的完整实时链路。

- **Google ADK · 4N+E：** 官方Live/Voice相关路径明确；延迟、打断与模型范围仍需实测。

- **Eino · U：** 框架可扩展，但本次未核实完整实时语音方案，不能按Go并发能力推断。


依据：[S53](#source-s53)。


**建议验证：** 测首音频时延、barge-in、断连恢复、回声处理及模型限制。


#### N3 跨服务 Agent 协作 / A2A

不同进程甚至不同框架的 Agent 能否交换任务与结果。


- **LangChain · 3E+A：** 可接外部协议adapter，不能把进程内多Agent调用当A2A。

- **LangGraph · 3E+A：** 图可调用远端Agent；协议任务生命周期和认证需外层管理。

- **Google ADK · 4E：** 官方A2A集成路径存在且页面标Experimental，需锁版本和验证兼容。

- **Eino · 3E+A：** 可通过外部SDK适配；本次不把未经核实的扩展算作开箱即用。


依据：[S54](#source-s54)、[S46](#source-s46)、[S42](#source-s42)、[S27](#source-s27)。


**建议验证：** 异构两端测试认证、取消、流式结果、版本不匹配和失败恢复。


#### N4 Skills 与按需加载能力

是否能把说明、资源和操作方法按需载入，而非一次塞进全部prompt。


- **LangChain · 3E+A：** 可借助独立harness/扩展或自己加载；不把Deep Agents所有能力算入LangChain核心。

- **LangGraph · 3E+A：** 图可组织加载流程，但不是graph本身的通用技能市场。

- **Google ADK · 4N+E：** 有官方Skills路径，页面标记Experimental；需检查允许资源和执行权限。

- **Eino · 4N：** 有Skill/AgentsMD等middleware路径；技能文本依然不能绕过工具权限。


依据：[S04](#source-s04)、[S55](#source-s55)、[S56](#source-s56)。


**建议验证：** 测试按需加载、版本更新、恶意技能文本与未授权文件路径。


### O 发布与持续运行

发布后，等待中的任务会与新代码、配置和工具版本同时存在。生产交付不仅是启动一个可调用的Agent。

**对选型的影响：** 将版本、调度、灰度和任务排空纳入系统设计；开源库与商业运行平台分开选型。


#### O1 Prompt、模型与配置版本

一次运行能否关联当时的模型、prompt、工具schema、流程及配置版本。


- **LangChain · 3A：** Agent配置可由代码管理，运行记录还需保存实际模型和middleware版本；选择prompt平台时另查许可。

- **LangGraph · 3A：** 图定义与state可带版本信息；checkpoint不会自动保存完整发布环境。

- **Google ADK · 3A：** Agent、Workflow和模型配置可版本化；session历史不能替代完整配置快照。

- **Eino · 3A：** Go程序版本可追踪，但动态prompt、模型路由和工具定义仍需独立记录。


依据：[S04](#source-s04)、[S06](#source-s06)、[S18](#source-s18)、[S30](#source-s30)。


**建议验证：** 用指定配置重现一次历史run，能准确列出当时依赖和动态配置，而不是只能找到Git提交。


#### O2 CI/CD、灰度发布与回滚

新版本上线或回滚时，运行中与等待中的旧任务如何处理。


- **LangChain · 2A+E：** 库可嵌入现有发布流程；新旧middleware与底层运行状态要一起回归。

- **LangGraph · 2A+E：** 图与serializer升级要兼容旧状态；路由到旧worker或排空任务由部署层安排。

- **Google ADK · 2A+E：** 要同时核对SDK、server和session schema；回滚程序不等于数据库也能回滚。

- **Eino · 2A+E：** 新旧Go二进制可并存，但checkpoint类型与中间件变化仍需迁移和恢复测试。


依据：[S06](#source-s06)、[S18](#source-s18)、[S30](#source-s30)、[S71](#source-s71)。


**建议验证：** 同时保留新旧任务做灰度，主动触发回滚，确认任务不丢失、不会重复执行外部操作。


#### O3 定时任务与外部事件触发

Cron或消息触发Agent时，触发记录、去重与失败重试由谁负责。


- **LangChain · 2A+E：** Agent可由应用调用；本表不把商业平台调度算入开源库默认部署。

- **LangGraph · 2A+E：** 可将图作为worker执行单元；持久触发队列、调度日历和触发去重需指定外部实现。

- **Google ADK · 2A+E：** Runner或API可作为执行入口；完整调度与消息确认需按具体服务组合评估。

- **Eino · 2A+E：** Go服务可接消息或定时器；本地timer不能代替跨副本持久调度。


依据：[S04](#source-s04)、[S05](#source-s05)、[S48](#source-s48)、[S63](#source-s63)。


**建议验证：** 计划触发前后分别停机，重复投递同一事件，核对触发记录、补跑和业务去重。


#### O4 长时间等待与优雅退出

人工等待数小时或数日，以及worker更新时，能否释放资源并让任务继续。


- **LangChain · 3N+A：** 可依赖底层interrupt保存等待状态；到期规则、通知和服务排空需应用实现。

- **LangGraph · 3N+A：** 持久interrupt可作为等待基础；审批到期、权限复验及版本路由需设计。

- **Google ADK · 3N+A：** RequestInput/resume提供等待入口；必须验证指定运行路径能跨进程继续。

- **Eino · 3N+A：** checkpoint与中断可保存等待状态；需避免只把等待内容保存在进程内存。


依据：[S07](#source-s07)、[S20](#source-s20)、[S21](#source-s21)、[S27](#source-s27)。


**建议验证：** 进入等待后释放worker，换进程继续；等待期间升级、过期或撤销权限都要有明确结果。


### P 数据与运行资产

运行状态之外，报告、文件、日志、记忆和备份也是需要治理的资产。删除、恢复与工具更新都可能跨多个系统。

**对选型的影响：** 需要原生生成物服务时重点看ADK；数据治理与灾备四条路线均需要部署级验收。


#### P1 文件、报告与生成物管理

生成的文件是否有名称、版本、访问范围和可控下载方式。


- **LangChain · 3E+A：** 模型和工具可处理文件引用；长期存储、下载和版本通常用外部服务。

- **LangGraph · 3E+A：** state宜保存生成物引用；大文件存储、链接授权和版本生命周期由应用管理。

- **Google ADK · 4N+E：** ArtifactService管理命名及版本化二进制内容，有session/user范围；下载权限仍需应用保证。

- **Eino · 3E+A：** 可用文件工具和外部对象存储；文件访问能力不等于完整报告发布与下载管理。


依据：[S68](#source-s68)、[S06](#source-s06)、[S66](#source-s66)。


**建议验证：** 对同名生成物生成两个版本，验证跨租户下载、过期链接、删除及超大文件行为。


#### P2 数据保留、脱敏与删除

删除用户数据时，checkpoint、memory、trace、缓存和文件能否一起处理。


- **LangChain · 2A：** 需协调会话状态与观测后端；一次删history不能证明所有副本被删除。

- **LangGraph · 2A：** checkpoint/store分开有利于定义范围，但保留、脱敏和删除闭环仍需设计。

- **Google ADK · 2A：** session、memory和artifact有各自服务；删除请求需覆盖这些服务与外部日志。

- **Eino · 2A：** store和扩展回调使用不同存储；应建立数据目录和统一删除流程。


依据：[S06](#source-s06)、[S22](#source-s22)、[S51](#source-s51)、[S68](#source-s68)。


**建议验证：** 用唯一合成标记追踪所有存储，执行保留/删除规则后逐一核对，记录备份残留的处理政策。


#### P3 备份、灾难恢复与RPO/RTO

整套数据库或区域失效后，能否恢复状态与业务操作记录，并量化丢失与恢复时间。


- **LangChain · 2A：** 恢复运行依赖底层存储备份；业务防重账本与checkpoint必须一起规划。

- **LangGraph · 2A：** checkpointer提供运行快照，数据库备份与跨区恢复是另一层责任。

- **Google ADK · 2A：** SessionService后端和artifact后端需分别备份，恢复后验证run与event关联。

- **Eino · 2A：** CheckPointStore接口不负责数据库灾备；外部资源实际状态还需对账。


依据：[S06](#source-s06)、[S22](#source-s22)、[S28](#source-s28)、[S71](#source-s71)。


**建议验证：** 从备份恢复到隔离环境，实测RPO和RTO，并核对恢复后是否重复外部操作。


#### P4 工具目录、schema与协议版本

工具新增、移除或修改参数后，旧计划和等待中的操作是否仍可安全执行。


- **LangChain · 3A+E：** provider/MCP适配提供接入路径；schema快照、工具版本和旧调用处置需应用策略。

- **LangGraph · 3A+E：** 图可以显式校验工具代际；仍需决定旧计划是兼容执行还是要求重新确认。

- **Google ADK · 3A+E：** MCP/OpenAPI工具可发现能力；发现新工具不自动授权执行旧计划。

- **Eino · 3A+E：** 工具接口与MCP扩展可接目录；缓存失效、schema变更与重新审批需自定义。


依据：[S10](#source-s10)、[S58](#source-s58)、[S59](#source-s59)、[S31](#source-s31)。


**建议验证：** 在人工等待期间改变工具参数或移除工具，验证旧输入被拒绝、迁移或重新确认。


## 关键边界与组合方式


### AI2UI：区分运行交互与界面协议

用户看到文字流、Agent 请求表单、Agent 拉起现有页面、Agent 返回新组件描述、前端控件操作回传，属于不同能力。仅能 interrupt/resume 不能证明完成了 AI2UI。

| 机制 | 主要解决什么 | 仍由产品与应用完成 |
|---|---|---|
| 框架 streaming / custom events | 输出过程和自定义数据 | 浏览器连接、事件存储、断线重放 |
| AG-UI | Agent 与前端间事件、状态及工具交互 | 框架适配、前端实现、权限与版本匹配 |
| A2UI | 用声明式数据描述界面与组件 | renderer、组件catalog、数据访问策略 |
| MCP Apps | 工具附带嵌入式交互 UI | 支持协议的host、隔离与能力授权 |
| 自定义 UI intent | 调用既有产品的页面或组件能力 | schema、动作白名单、版本和生命周期管理 |

可组合使用这些机制。例如 Agent 发出 ResourceDetail 的展示请求，前端按本地注册组件打开详情，用户调整过滤条件后回传结构化数据，再继续查询。Agent 不需要获得任意执行浏览器脚本的能力。附件 C06 展示这种数据边界，但没有实现 renderer，因此不能宣称通过了任何公开协议的兼容测试。


依据：[S08 Streaming](https://docs.langchain.com/oss/python/langgraph/streaming)；[S32 Eino A2UI quickstart](https://www.cloudwego.io/docs/eino/quick_start/chapter_10_a2ui_protocol/)；[S33 A2UI v0.9.1](https://a2ui.org/specification/v0.9.1-a2ui/)；[S35 AG-UI introduction](https://docs.ag-ui.com/introduction)；[S36 MCP Apps 官方 SDK/spec](https://github.com/modelcontextprotocol/ext-apps)。

### Checkpoint、幂等与事务

checkpoint 是运行状态记录。外部 API 操作可能已经成功，但框架还没保存下一条记录，进程便退出。恢复后同一步可能再次执行。解决方法取决于外部系统：可用稳定的 idempotency key、防重表、outbox，或读取实际状态后做 reconciliation。框架恢复和业务事务之间没有天然的跨系统原子性。

等待用户时还要处理重复提交、过期表单、权限变更和两个 worker 同时恢复。这些是 D2、E4、F1/F2 与 I3 的交叉验收事项，不应分别得分后就假定组合一定正确。C07 专门展示了“调用尝试两次、业务记录一次”的区别。


依据：[S06 Checkpointers](https://docs.langchain.com/oss/python/langgraph/checkpointers)；[S07 Interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts)；[S21 ADK resume](https://adk.dev/runtime/resume/)；[S27 Eino HITL](https://www.cloudwego.io/docs/eino/core_modules/eino_adk/agent_hitl/)；[S28 Eino checkpoint 手册](https://www.cloudwego.io/docs/eino/core_modules/chain_and_graph_orchestration/checkpoint_interrupt/)；本地证据：附件 C07。

### GIL、异步与多租户

默认 CPython 的 GIL 限制同一进程中 Python 字节码的线程并行，不会把正确使用 async 的网络等待全部串行化。相反，把纯 Python 的重计算或阻塞 SDK 放进 event loop，会阻塞其他任务；需要转到合适的线程、进程或外部 worker，具体取决于代码是否释放 GIL。

Go 的 goroutine 提供不同的并发实现方式，但模型等待、数据库写入、连接池和供应商限额仍可能成为瓶颈。容器解决运行环境交付问题，不会自动解决 CPU 或隔离问题。必须把框架机制、资源占用和多租户公平调度分开评估。


依据：[S38 CPython threading](https://docs.python.org/3/library/threading.html)；[S39 CPython asyncio](https://docs.python.org/3/library/asyncio.html)；[S64 Effective Go — concurrency](https://go.dev/doc/effective_go#concurrency)；本地证据：附件 C08。



## 核心代码与实验记录


以下代码用于解释具体机制，不能据此给所有比较项标记“验证通过”。C01/C02/C05 2026-10-06执行；C07/C08 复用2026-10-06先前通用实验原始记录。C03 未装载 ADK 运行，C04 未编译。实验不用真实模型或真实云平台，所以不评价模型效果和生产性能。

| 编号 | 内容 | 状态 / 能证明的范围 |
|---|---|---|
| C01 | LangChain 工具循环 | T：真实 create_agent + 固定模型替身，工具结果 14 |
| C02 | LangGraph 结构化表单 | T：interrupt 返回表单，校验后恢复；仅 InMemorySaver |
| C03 | ADK RequestInput | D：参照官方 2.x 示例编写；仅 Python 语法检查，未运行 |
| C04 | Eino typed graph | D：核心图 API 示例；无 Go 环境，未编译，无 go.sum |
| C05 | 应用侧权限与版本校验 | T：正常请求通过，5 类非法请求拒绝；不是完整认证系统 |
| C06 | 自定义 UI intent 数据 | 设计示例：不是 A2UI / AG-UI wire schema，无前端实测 |
| C07 | SQLite checkpoint + 强退恢复 | T：独立进程恢复，外部效果尝试 2 次，防重记录 1 条 |
| C08 | 异步 I/O 与 CPU 干扰 | T：单机合成负载；没有四框架同场对比 |

### C01 LangChain：高层工具调用

模型替身使测试确定性运行；它不测模型决策质量。

```python
agent = create_agent(model=ScriptedModel(), tools=[double_number])
result = agent.invoke({'messages':[{'role':'user','content':'Double 7'}]})
```

完整代码：附件内 `langchain_tool_demo.py`。

### C02 LangGraph：结构化输入与恢复

返回值必须自行校验；内存 saver 不能跨进程持久恢复。

```python
def collect(state):
    value = interrupt({'form':'query', 'fields':['region','days']})
    if set(value) != {'region','days'} or type(value['days']) is not int:
        raise ValueError('Unexpected fields or days type')
    if value['region'] not in ['east','west'] or not 1 <= value['days'] <= 30:
        raise ValueError('Invalid form values')
    return {'answer':value}
```

完整代码：附件内 `langgraph_form_demo.py`。

### C03 Google ADK：Workflow 请求输入

未运行；官方文档支持 RequestInput 路径，但完整运行环境兼容性尚待验证。

```python
def ask_number():
    yield RequestInput(message='Enter an integer from 1 to 30')


def calculate(node_input):
    value = int(node_input)
    if not 1 <= value <= 30:
        raise ValueError('Value must be from 1 to 30')
    return value * 2


root_agent = Workflow(name='input_demo', edges=[('START',ask_number,calculate)])
```

完整代码：附件内 `adk_input_demo/agent.py`。

### C04 Eino：显式类型的节点

未编译；完整程序包含连边、Compile、Invoke和输出断言。

```go
graph := compose.NewGraph[int, int]()
err := graph.AddLambdaNode("double", compose.InvokableLambda(
    func(ctx context.Context, input int) (int, error) {
        if input < 1 || input > 30 {
            return 0, fmt.Errorf("input must be from 1 to 30")
        }
        return input * 2, nil
    }))
```

完整代码：附件内 `eino_graph_demo/main.go`。

### C05 应用：身份、资源权限与旧表单拒绝

身份必须来自可信认证上下文；本函数不负责token校验、数据库隔离或并发防重。

```python
def authorize(identity, owner, event, current_revision, visible_resources):
    if identity != owner:
        raise PermissionError('Wrong owner')
    if set(event) != {'revision','action','resource_id'}:
        raise ValueError('Unexpected event fields')
    if event['revision'] != current_revision:
        raise ValueError('Stale interaction')
    if event['action'] not in {'open_detail','submit_query'}:
        raise PermissionError('Action is not allowed')
    if event['resource_id'] not in visible_resources:
        raise PermissionError('Resource is not visible')
    return {'action':event['action'],'resource_id':event['resource_id']}
```

完整代码：附件内 `application_boundary_demo.py`。

### C06 自定义 UI intent

这是自定义数据格式的示意。服务端发出展示意图，浏览器用预注册组件渲染，用户事件交给 C05 校验，再路由到任务；不能把 client_to_server 中的字段当作可信身份。

```json
{
  "note": "Custom illustrative protocol; NOT AG-UI or A2UI schema",
  "server_to_client": {
    "type": "show_resource_panel",
    "surface_id": "resource-panel",
    "revision": 2,
    "component": "ResourceDetail",
    "props": {
      "resource_id": "r1"
    },
    "allowed_actions": [
      "open_detail",
      "submit_query"
    ]
  },
  "client_to_server": {
    "revision": 2,
    "action": "open_detail",
    "resource_id": "r1"
  }
}
```

完整数据：附件内 `ui_event_example.json`。

### C07 故障后副作用可能重试

下面摘录的是业务效果节点。防重来自应用数据库的唯一键与 INSERT OR IGNORE，不是框架自动保证远端 API exactly-once。强退测试只影响脚本启动的子进程。

```python
def effect(state):
    count(folder, 'effect_attempt')
    # Simulates an external service's idempotency ledger in a SEPARATE DB.
    # A real remote API must provide equivalent semantics or require reconciliation.
    with connect(folder) as db:
        db.execute('INSERT OR IGNORE INTO effects VALUES (?,?)', ('tenant-a/run-1/report-1', 'created'))
    if crash:
        os._exit(73)  # after effect commit, before graph checkpoint acknowledgement
    return {'report': 'report-1'}
```

完整进程恢复与并发提交实验：附件内 `langgraph_probe.py`，原始结果：附件内 `results/langgraph-probe.json`。实际记录 prepare 1 次、interrupt 前逻辑 2 次、effect 尝试 2 次、唯一效果 1 条。另有应用事务的 20 路并发提交实验：接受 1 次；这不证明框架原生实现了多 worker 锁。

### C08 I/O 与 CPU 干扰

下面是同一个异步节点，有意加入纯 Python 计算以观察 event loop 受阻。四个连续节点各调用本机 TCP mock，服务端等待 50 ms；异步 SQLite saver 使用 sync durability。不是 LLM 性能实验。

```python
async def node(state):
    reader, writer = await asyncio.open_connection('127.0.0.1', port)
    writer.write(b'query\n')
    await writer.drain()
    await reader.readline()
    writer.close()
    await writer.wait_closed()
    if cpu_work:
        # Intentionally bad: pure Python CPU on the event loop, blocking ALL requests.
        sum(i * i for i in range(150000))
    return {'value': state['value'] + 1}
```

环境：Windows、Python 3.14.6、LangGraph 1.2.13、8 个逻辑 CPU、GIL 开启；每组 3 次短批次。P95 按每批完成请求计算；少量样本的尾部统计不稳定，不能作为 SLA。RSS 是进程峰值采样，不包含数据库服务或生产网关。

| 并发任务 | 节点内 CPU 计算 | P95 范围（秒） | 峰值 RSS 最大值（MiB） |
|---|---|---|---|
| 10 | 无 | 0.3695–0.3904 | 79.23 |
| 10 | 有 | 0.7529–0.7919 | 81.30 |
| 50 | 无 | 1.4953–1.5868 | 82.21 |
| 50 | 有 | 3.5681–3.5990 | 81.96 |

结果仅说明该实现存在并发 I/O 路径，且 CPU 放置方式会影响等待时间；SQLite、操作系统调度等因素也参与其中。没有把差异单独归因于 GIL，也没有把此结果用于给四框架性能打分。

完整负载脚本：附件内 `concurrency_probe.py`，原始结果：附件内 `results/concurrency-probe.json`。



## 采用前验收与落地步骤

### 分阶段落地

先固定首选与备选、版本和目标组件；用相同模型替身与持久化要求验证机制；再接真实模型与业务工具验证效果；最后验证部署、恢复、权限和运行成本。任何阶段失败都应修正组合或换选。

一个可验收组合至少要列出：编排库、模型/provider、工具/协议adapter、持久化后端、任务调度、鉴权、观测、UI协议与renderer。这样才能避免“选了一个框架”却不知道剩余模块谁负责。

### 必须能改变决策的测试


| 测试 | 通过条件 | 当前证据 |
| --- | --- | --- |
| 跨进程中断恢复 | 等待记录可读回，输入继续传递到正确步骤 | C07仅验证LangGraph+SQLite局部路径 |
| 外部操作防重 | 在远端成功、checkpoint前退出后，无重复业务效果或有明确对账 | C07由模拟下游唯一键保证，真实API待测 |
| 重复提交与多worker | 同一交互至多被有效接受一次，旧worker不能重复执行 | C07仅应用SQLite事务20路提交，不是分布式租约 |
| 权限撤销与跨租户 | 恢复和工具执行前重验权限，所有读/列出/删除入口隔离 | C05/C07仅局部应用校验 |
| UI交互与断线 | 多字段输入、页面操作、重复事件与过期表单结果明确 | C02/C06没有renderer，待真实前端验收 |
| 组件兼容 | 目标模型的工具/结构化/usage能力，MCP transport和认证均通过 | 真实模型与MCP未测 |
| 升级与回滚 | 旧等待任务能兼容、迁移或明确拒绝，灰度回滚不丢任务 | 四框架均未跨版本测试 |
| 公平调度与取消 | 单租户突发时其他租户仍能完成，取消后不启动新操作 | 未做多副本多租户负载 |
| 性能与资源 | 在业务正确性相同前提下满足时延、错误和资源预算 | C08仅短批次合成负载 |
| 质量与成本 | 相同任务/模型多次采样，关键错误人工复核，记录token与费用 | 没有真实模型效果数据 |
| 数据保留与灾备 | 覆盖状态/日志/文件/记忆/备份，实测RPO/RTO和删除流程 | 未做部署级演练 |
| 离线与供应链 | 目标环境可构建运行，外联、许可和制品来源可追溯 | 有实验依赖快照，没有完整安全审计 |


吞吐实验应分成框架开销与端到端两层：前者使用固定mock，后者使用相同真实模型与任务。两层均固定硬件、持久性、节点数与数据规模，记录P50/P95/P99、错误、资源和业务效果。选择最小成本时，要同时计入模型、基础设施、软件产品和自建人力。

### 决策记录与复评条件

采用后保存这组信息：选择及其前提、比较过的备选、决定性证据、仍需建设的模块、已知代价、验收结果和复评触发条件。模型/provider不再兼容、无法满足资源预算、升级导致旧任务无法继续、或某备选显著减少自建成本时，重新评估。此组织方法参考Google的ADR指南；并不意味着Google为本报告的框架结论背书。[S70](#source-s70)。


## 本次文档验收与证据边界

本次整合将场景结论、评分、逐维度理由、来源和核心代码置于同一阅读文档，新增发布与数据治理8项，并再次修正继承能力与安全等依据不足的分差。逐项改动记录、独立review输入和完整校验结果位于附件的 `review/` 与 `metadata/`。

已经检查UTF-8、所有内部目标、矩阵与正文数据一致性、附件引用、代码语法及压缩包校验。浏览器验收检查文首、矩阵、长段落与窄屏布局；打印规则另做样式检查，尚未逐页验证纸面输出。文档验收与框架生产验收分开：ADK/Eino代码状态及真实模型、renderer、多副本实验的缺口均按原证据保留。

### 资料组织参考

Microsoft的选型指南按需求与场景组织比较，并明确技术、运维、安全及团队因素；Google的ADR指南强调记录决策背景、选项和后果。本文借用这种组织方法，评分和Agent结论由本报告负责。[S70](#source-s70)、[S71](#source-s71)。


| 案例 | 链接 | 适用边界 |
| --- | --- | --- |
| Microsoft：Choose an Azure compute service | [Microsoft：Choose an Azure compute service](https://learn.microsoft.com/en-us/azure/architecture/guide/technology-choices/compute-decision-tree) | 仅参考选型组织与表达，不作为Agent能力证据 |
| Google：Multicloud database management: Architectures, use cases, and best practices | [Google：Multicloud database management: Architectures, use cases, and best practices](https://docs.cloud.google.com/architecture/multi-cloud-database-management) | 仅参考选型组织与表达，不作为Agent能力证据 |
| 阿里云：如何选择阿里云数据库服务 | [阿里云：如何选择阿里云数据库服务](https://help.aliyun.com/zh/decision-guides/how-to-choose-database-service) | 仅参考选型组织与表达，不作为Agent能力证据 |
| 华为云：数据库服务决策指南 | [华为云：数据库服务决策指南](https://support.huaweicloud.com/how-to-choose-databases/db_0001.html) | 仅参考选型组织与表达，不作为Agent能力证据 |
| 华为云：存储云服务选型指导 | [华为云：存储云服务选型指导](https://support.huaweicloud.com/intl/zh-cn/how-to-choose-storage/storage_0001.html) | 仅参考选型组织与表达，不作为Agent能力证据 |


## 来源与附件

在线文档会变化。来源索引保留精确URL和访问日期；固定版本源码以URL中的版本为准。本次不宣称已离线归档所有网页。S15等第三方集成只代表其维护方，不能视为核心团队支持承诺；S54/S55包含Experimental标记；S29旧版参考由S67核对当前基线。


### S01 LangGraph PyPI

[LangGraph PyPI](https://pypi.org/project/langgraph/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S02 固定版本 pyproject

[固定版本 pyproject](https://raw.githubusercontent.com/langchain-ai/langgraph/1.2.13/libs/langgraph/pyproject.toml) · 访问 2026-10-06 · 固定版本源码


### S03 LangChain PyPI

[LangChain PyPI](https://pypi.org/project/langchain/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S04 LangChain overview

[LangChain overview](https://docs.langchain.com/oss/python/langchain/overview) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S05 LangGraph overview

[LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S06 Checkpointers

[Checkpointers](https://docs.langchain.com/oss/python/langgraph/checkpointers) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S07 Interrupts

[Interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S08 Streaming

[Streaming](https://docs.langchain.com/oss/python/langgraph/streaming) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S09 Memory / database savers

[Memory / database savers](https://docs.langchain.com/oss/python/langgraph/add-memory) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S10 LangChain MCP

[LangChain MCP](https://docs.langchain.com/oss/python/langchain/mcp) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S11 LangChain testing

[LangChain testing](https://docs.langchain.com/oss/python/langchain/test) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S12 LangSmith self-hosted

[LangSmith self-hosted](https://docs.langchain.com/langsmith/self-hosted) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S13 Langfuse LangChain integration

[Langfuse LangChain integration](https://langfuse.com/integrations/frameworks/langchain) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S14 LangGraph.js

[LangGraph.js](https://github.com/langchain-ai/langgraphjs) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S15 MySQL saver 维护者仓库

[MySQL saver 维护者仓库](https://github.com/tjni/langgraph-checkpoint-mysql) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S16 MongoDB 集成仓库

[MongoDB 集成仓库](https://github.com/langchain-ai/langchain-mongodb) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S17 Google ADK PyPI

[Google ADK PyPI](https://pypi.org/project/google-adk/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S18 Google ADK releases

[Google ADK releases](https://github.com/google/adk-python/releases) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S19 ADK graph workflows

[ADK graph workflows](https://adk.dev/graphs/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S20 ADK human input

[ADK human input](https://adk.dev/graphs/human-input/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S21 ADK resume

[ADK resume](https://adk.dev/runtime/resume/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S22 ADK session service

[ADK session service](https://adk.dev/sessions/session/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S23 ADK evaluation

[ADK evaluation](https://adk.dev/evaluate/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S24 ADK safety

[ADK safety](https://adk.dev/safety/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S25 ADK Go

[ADK Go](https://github.com/google/adk-go) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S26 Eino releases

[Eino releases](https://github.com/cloudwego/eino/releases) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S27 Eino HITL

[Eino HITL](https://www.cloudwego.io/docs/eino/core_modules/eino_adk/agent_hitl/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S28 Eino checkpoint 手册

[Eino checkpoint 手册](https://www.cloudwego.io/docs/eino/core_modules/chain_and_graph_orchestration/checkpoint_interrupt/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S29 Eino 0.9.19 workflow 源码

[Eino 0.9.19 workflow 源码](https://raw.githubusercontent.com/cloudwego/eino/v0.9.19/adk/workflow.go) · 访问 2026-10-06 · 固定版本源码


### S30 Eino v0.9 migration

[Eino v0.9 migration](https://www.cloudwego.io/docs/eino/release_notes_and_migration/eino_v0.9._agentic-runtime/eino_v0.9_migration_notes/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S31 Eino extensions

[Eino extensions](https://github.com/cloudwego/eino-ext) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S32 Eino A2UI quickstart

[Eino A2UI quickstart](https://www.cloudwego.io/docs/eino/quick_start/chapter_10_a2ui_protocol/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S33 A2UI v0.9.1

[A2UI v0.9.1](https://a2ui.org/specification/v0.9.1-a2ui/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S34 A2UI 仓库

[A2UI 仓库](https://github.com/a2ui-project/a2ui) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S35 AG-UI introduction

[AG-UI introduction](https://docs.ag-ui.com/introduction) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S36 MCP Apps 官方 SDK/spec

[MCP Apps 官方 SDK/spec](https://github.com/modelcontextprotocol/ext-apps) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S37 MCP security practices

[MCP security practices](https://modelcontextprotocol.io/docs/2025-11-25/tutorials/security/security_best_practices) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S38 CPython threading

[CPython threading](https://docs.python.org/3/library/threading.html) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S39 CPython asyncio

[CPython asyncio](https://docs.python.org/3/library/asyncio.html) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S40 LangChain middleware

[LangChain middleware](https://docs.langchain.com/oss/python/langchain/middleware/overview) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S41 LangChain structured output

[LangChain structured output](https://docs.langchain.com/oss/python/langchain/structured-output) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S42 LangGraph graph API

[LangGraph graph API](https://docs.langchain.com/oss/python/langgraph/graph-api) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S43 Eino components

[Eino components](https://www.cloudwego.io/docs/eino/core_modules/components/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S44 ADK callbacks

[ADK callbacks](https://adk.dev/callbacks/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S45 LangChain models

[LangChain models](https://docs.langchain.com/oss/python/langchain/models) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S46 LangChain multi-agent

[LangChain multi-agent](https://docs.langchain.com/oss/python/langchain/multi-agent) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S47 ADK observability

[ADK observability](https://adk.dev/observability/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S48 ADK deployment

[ADK deployment](https://adk.dev/deploy/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S49 ADK context compression

[ADK context compression](https://adk.dev/context/compaction/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S50 LangChain short-term memory

[LangChain short-term memory](https://docs.langchain.com/oss/python/langchain/short-term-memory) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S51 ADK memory

[ADK memory](https://adk.dev/sessions/memory/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S52 Retrieval（原 LangChain 入口现转至 Deep Agents）

[Retrieval（原 LangChain 入口现转至 Deep Agents）](https://docs.langchain.com/oss/python/deepagents/retrieval) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S53 ADK Live and Voice

[ADK Live and Voice](https://adk.dev/live/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S54 ADK A2A

[ADK A2A](https://adk.dev/a2a/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S55 ADK Skills

[ADK Skills](https://adk.dev/skills/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S56 Eino Skill middleware

[Eino Skill middleware](https://www.cloudwego.io/docs/eino/core_modules/eino_adk/eino_adk_chatmodelagentmiddleware/middleware_skill/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S57 ADK Simple agents

[ADK Simple agents](https://adk.dev/agents/llm-agents/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S58 ADK MCP tools

[ADK MCP tools](https://adk.dev/tools-custom/mcp-tools/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S59 ADK OpenAPI tools

[ADK OpenAPI tools](https://adk.dev/tools-custom/openapi-tools/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S60 Eino graph introduction

[Eino graph introduction](https://www.cloudwego.io/docs/eino/core_modules/chain_and_graph_orchestration/chain_graph_introduction/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S61 LangChain human-in-the-loop

[LangChain human-in-the-loop](https://docs.langchain.com/oss/python/langchain/human-in-the-loop) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S62 LangGraph releases

[LangGraph releases](https://github.com/langchain-ai/langgraph/releases) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S63 Eino 仓库与许可证入口

[Eino 仓库与许可证入口](https://github.com/cloudwego/eino) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S64 Effective Go — concurrency

[Effective Go — concurrency](https://go.dev/doc/effective_go#concurrency) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S65 Eino v0.9.21 go.mod

[Eino v0.9.21 go.mod](https://raw.githubusercontent.com/cloudwego/eino/v0.9.21/go.mod) · 访问 2026-10-06 · 固定版本源码


### S66 Eino middleware

[Eino middleware](https://www.cloudwego.io/docs/eino/core_modules/eino_adk/eino_adk_chatmodelagentmiddleware/) · 访问 2026-10-06 · 在线文档/项目元数据；可能更新


### S67 Eino v0.9.21 Workflow Agent 源码

[Eino v0.9.21 Workflow Agent 源码](https://raw.githubusercontent.com/cloudwego/eino/v0.9.21/adk/workflow.go) · 访问 2026-10-06 · 固定版本源码


### S68 ADK Artifacts

[ADK Artifacts](https://adk.dev/artifacts/) · 访问 2026-10-07 · 官方文档


### S70 Google Cloud Architecture decision records

[Google Cloud Architecture decision records](https://docs.cloud.google.com/architecture/architecture-decision-records) · 访问 2026-10-07 · 官方文档


### S71 Microsoft Prepare to choose a data store

[Microsoft Prepare to choose a data store](https://learn.microsoft.com/en-us/azure/architecture/guide/technology-choices/data-stores-getting-started) · 访问 2026-10-07 · 官方文档


### S72 Eino Agent Collaboration

[Eino Agent Collaboration](https://www.cloudwego.io/docs/eino/core_modules/eino_adk/agent_collaboration/) · 访问 2026-10-07 · 官方文档


### S73 Eino v0.9.21 graph_run.go

[Eino v0.9.21 graph_run.go](https://raw.githubusercontent.com/cloudwego/eino/v0.9.21/compose/graph_run.go) · 访问 2026-10-07 · 固定版本源码


### S74 LangChain Streaming

[LangChain Streaming](https://docs.langchain.com/oss/python/langchain/streaming) · 访问 2026-10-07 · 官方文档


### 唯一附件

下载同目录的 **[Agent框架选型附件.zip](Agent框架选型附件.zip)**。解压后包含：

- `code/`：完整示例、运行说明、实验依赖快照和原始结果。
- `metadata/`：64项评分数据、来源索引、验收结果与文件hash。
- `review/`：独立案例收集、独立技术复核与本次决策修正记录。
- `source/`：本文可编辑Markdown和生成程序。阅读本文不依赖这些文件。

文档可直接在浏览器离线打开；引用的在线资料需联网查看。HTML内置样式，不加载外部字体或脚本。打印时隐藏目录与工具栏，保留全部正文及代码。
