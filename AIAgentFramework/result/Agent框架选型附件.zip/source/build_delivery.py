"""Create exactly one standalone reading document and one self-contained attachment."""
from pathlib import Path
import ast
import copy
import hashlib
import html
from html.parser import HTMLParser
import json
import re
import shutil
import sys
import unicodedata
from urllib.parse import unquote
import zipfile
from markdown_it import MarkdownIt

BASE = Path(__file__).resolve().parent.parent
WORKSPACE = BASE.parent.parent
OUT = WORKSPACE/'交付成果'
STAGE = BASE/'internal'/'package'
sys.path.insert(0,str(BASE))
from comparison_data import ROWS
from delivery_additions import EXTRA_ROWS

ROWS = copy.deepcopy(ROWS) + copy.deepcopy(EXTRA_ROWS)
NAMES = ['LangChain','LangGraph','Google ADK','Eino']
sources = json.loads((BASE/'sources.json').read_text(encoding='utf-8'))
new_sources = {
    'S68':('ADK Artifacts','https://adk.dev/artifacts/'),
    'S70':('Google Cloud Architecture decision records','https://docs.cloud.google.com/architecture/architecture-decision-records'),
    'S71':('Microsoft Prepare to choose a data store','https://learn.microsoft.com/en-us/azure/architecture/guide/technology-choices/data-stores-getting-started'),
    'S72':('Eino Agent Collaboration','https://www.cloudwego.io/docs/eino/core_modules/eino_adk/agent_collaboration/'),
    'S73':('Eino v0.9.21 graph_run.go','https://raw.githubusercontent.com/cloudwego/eino/v0.9.21/compose/graph_run.go'),
    'S74':('LangChain Streaming','https://docs.langchain.com/oss/python/langchain/streaming'),
}
for key,(title,url) in new_sources.items():
    sources[key] = dict(title=title,url=url,access_date='2026-10-07',evidence_type='固定版本源码' if key=='S73' else '官方文档')

# Same underlying capability is not penalized merely because a higher-level API exposes it.
changes = {
    'D4':(['4N+A','4N+A','3N+A','3N+A'],'LangChain历史能力与底层一致，跨版本兼容仍应用负责'),
    'E1':(['5N','5N','4N','4N'],'LangChain与LangGraph共享streaming基础'),
    'E4':(['3N+A','3N+A','2A','2A'],'LangChain与LangGraph共享状态恢复基础'),
    'G3':(['4N+A','4N+A','4N+A','4N+A'],'不因高层入口对继承的取消机制扣分'),
    'F4':(['2A+E']*4,'安全文档与回调入口不证明更强注入防护或sandbox'),
    'B1':(['4E','4E','4N+E','4E'],'未量化provider覆盖与兼容性，不以生态印象给5分'),
    'B2':(['5N+E','4E+A','4N+E','U'],'Eino结构化输出缺少目标provider组合证据，保留U'),
    'C4':(['4A+E','4N+A','4N+A','4N+A'],'图state与AgentTool均可限制输入，按实际模式而非整个框架推断共享历史'),
    'H2':(['4E','4E','4N+E','3A+E'],'有集中评测入口是路径优势，未实测全流程不赋予满分'),
    'J2':(['3N']*4,'确认文档覆盖，未开展四框架同场排错测量'),
    'N1':(['4N+E','4E+A','4N+E','4N+E'],'不凭文档篇幅或Beta接口对锁定基线推断多模态质量差距'),
}
for row in ROWS:
    if row['id'] in changes: row['scores'] = changes[row['id']][0]
    if row['id']=='B1':
        row['notes'][1]='可直接调用模型 SDK，或复用 LangChain provider packages；可复用接口，实际兼容范围仍需按模型验证。'
    if row['id']=='B2':
        row['notes'][3]='Go 解码和工具 schema 能构成实现基础；尚未核对目标provider的原生schema约束、错误重试和tools组合，不作相对完整度评分。'
    if row['id']=='F4':
        row['notes'][2]='官方有安全实践与callback入口，可组合工具限制；本次无证据证明其注入防御或代码隔离强于其他框架。'
    if row['id']=='C4':
        row['notes'][1]='子图 state 和输入映射让信息边界显式；是否泄露共享state仍取决于应用输入与授权设计。'
        row['notes'][3]='AgentTool默认只接收模型生成的请求参数，完整history需要显式启用；特定Workflow Agent会共享上下文，应按协作模式选择。'
        row['sources'] = ['S46','S42','S22','S67','S72']
    if row['id']=='D1':
        row['notes'][2]='Session/Event与resume提供恢复路径；官方文档对工具重复、自定义Agent、Web/CLI有明确限制。2.x Workflow组合未在本次验证。'
        row['notes'][3]='有中断保存与CheckPointStore，store由使用者实现；v0.9.21普通图运行不是默认每个完成节点都持久保存。中断恢复不等于任意强杀后的逐步恢复。'
        row['sources'].append('S73')
        row['note_sources']=[['S04','S06'],['S06'],['S21'],['S28','S73']]
    if row['id']=='C4':row['note_sources']=[['S46'],['S42'],['S22'],['S72','S67']]
    if row['id'] in ['D4','E1','E4','G3']:row['sources'].append('S74')
    if row['id']=='K1' and 'S63' not in row['sources']: row['sources'].append('S63')
    if row['id']=='G1' and 'S64' not in row['sources']: row['sources'].append('S64')
    if row['id']=='I4' and 'S65' not in row['sources']: row['sources'].append('S65')

def refs(ids):
    return '、'.join(f'[{key}](#source-{key.lower()})' for key in dict.fromkeys(ids))

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |'] +
                      ['| '+' | '.join(str(v).replace('|','\\|') for v in row)+' |' for row in rows])+'\n'

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(value,encoding='utf-8')

groups = list(dict.fromkeys(row['group'] for row in ROWS))
group_intro = {
'A':('先看开发者如何写代码和定位错误。简单Agent的起步成本，与复杂系统的可控制程度，应分别比较。','普通循环优先LangChain；代码中的业务函数在四种框架中都应独立于运行时。'),
'B':('模型、MCP与HTTP工具是最容易复用生态的地方，也最容易出现“聊天可用、工具调用不兼容”的情况。接口存在和目标组件通过测试是两层证据。','已有adapter满足模型与协议时优先复用；缺少目标能力会推翻其他维度的优势。'),
'C':('流程控制决定哪些步骤必须执行、并行结果如何合并、子Agent看到哪些信息。多Agent数量不直接代表质量。','显式复杂流程推荐LangGraph；ADK Workflow和Eino compose同样应进入备选验证。'),
'D':('运行状态保存、用户等待、崩溃重试与升级恢复应分别核对。外部API成功但运行记录尚未提交，是所有路线都要处理的窗口。','细粒度恢复是LangGraph的主要推荐理由；业务幂等、防重和对账仍需单独设计。'),
'E':('交互既包括文字流，也包括多字段表单、图表、既有页面和前端动作。恢复后能继续执行，不等于浏览器界面已经恢复。','复杂交互推荐图编排加UI协议；仅有固定表单时，高层Agent入口也可满足需求。'),
'F':('身份、权限、秘密数据与不可信内容必须在实际执行入口检查。这里的低分表示应用责任较多，不是已发现框架漏洞。','四者都需完整授权与数据治理；不能以某框架的总分代替越权测试。'),
'G':('任务怎样等待、重试、取消和排队，决定系统在负载和错误下的行为。异步能力与生产容量分开比较。','先用非阻塞I/O和限额设计，再测瓶颈；Go和Python各自的机制不能替代负载测试。'),
'H':('观测帮助找到错误，测试帮助复现错误，质量评测帮助判断换模型后有没有退化，审计则回答谁批准和执行了操作。','希望开发与评测入口集中时优先ADK；其他框架可接外部评测与观测服务。'),
'I':('部署形态、存储适配和多副本协调共同决定可运维性。共享数据库只能提供部分基础，并不自动实现整次run互斥。','运行时为硬约束时优先筛语言；其余路线以目标数据库和故障接管验收决定。'),
'J':('维护成本来自升级、依赖组合、过时示例和问题响应。近期发布能证明有活动，不能证明未来维护承诺或修复SLA。','锁定版本与组件组合；没有采集响应统计前，不按社区印象淘汰候选。'),
'K':('核心许可、商业平台、自建人力、模型调用和退出迁移共同构成成本。某个软件包免费不等于整个运行平台低成本。','按同等功能范围列费用与人力；退出方案先保留普通业务状态，再规划旧任务排空。'),
'L':('吞吐、内存、长期增长和实际成功率必须用相同条件测量。现有短批次LangGraph实验只能解释局部机制。','保留U，不发布性能冠军；达到业务正确性要求后再比较资源效率。'),
'M':('短期会话历史、长期事实记忆、RAG和摘要承担不同职责。记忆能查到不等于内容正确，也不等于当前用户有权使用。','简单RAG可从LangChain起步；多阶段检索与验证用LangGraph组织，其他路线按组件匹配。'),
'N':('多模态、实时语音、跨服务Agent和Skills有不同协议及运行要求。普通streaming不能推导全部扩展能力。','受支持Live场景优先ADK；A2A与Skills的实验性状态及版本应单独控制。'),
'O':('发布后，等待中的任务会与新代码、配置和工具版本同时存在。生产交付不仅是启动一个可调用的Agent。','将版本、调度、灰度和任务排空纳入系统设计；开源库与商业运行平台分开选型。'),
'P':('运行状态之外，报告、文件、日志、记忆和备份也是需要治理的资产。删除、恢复与工具更新都可能跨多个系统。','需要原生生成物服务时重点看ADK；数据治理与灾备四条路线均需要部署级验收。'),
}

parts = ['''# 企业级 AI Agent 框架选型说明书

版本 2.0 · 整合与复核日期：2026-10-07 · 通用选型，独立于现有业务背景

本说明书帮助架构与开发团队在 LangChain、LangGraph、Google ADK 和 Eino 中选择合适路线。内容覆盖设计、开发、交互、恢复、安全、并发、测试、发布、数据治理、维护与成本。读者可以先完成场景决策，再沿编号查评分理由与证据。

**技术路线建议：复杂且需要恢复的流程，推荐 LangGraph 作为编排核心；常规聊天和工具循环，推荐 LangChain；希望统一 Agent 开发与评测，或采用受支持实时语音链路，推荐 Google ADK；明确要求 Go 集成或交付，优先 Eino。** 每项建议都有前提和换选条件。性能与生产稳定性的相对优胜结论尚未取得。

阅读路线：决策者先读“范围与场景决策”；架构师读“比较矩阵”与关键能力分析；实现与验收人员读“核心代码”和“采用前验收”。所有完整代码、数据与复现说明均在同目录的唯一附件 `Agent框架选型附件.zip` 中。

## 范围与评估基线

本版比较开源框架与明确标出的扩展路径，不代入当前业务的运行时、并发数、数据库或预算。此前的评分与场景指南已经并入本文；读完本文不需要再打开另一个说明文档。
''']
parts.append(table(['候选','本版基线','主要责任','使用边界'],[
['LangChain','Python 1.4.3','高层Agent循环、模型/工具与middleware','Agent建立在LangGraph上，底层能力不重复扣分'],
['LangGraph','Python 1.2.13','显式state、节点、边、持久执行','库本身不是任务调度与租户管理平台'],
['Google ADK','Python 2.11.0','Agent、Runner、Session、Workflow及eval','各语言SDK和旧版/2.x路径分别核对'],
['Eino','Go v0.9.21','compose、ADK、middleware及组件','扩展与存储实现另行锁定版本'],
]))
parts.append('''上述是2026-10-06研究时锁定的评估基线，本次整合没有把它们更新成“今天最新版本”。在线文档可能已演进，生产采用时应按锁定组合重新验证。核心包、provider、saver、协议adapter及商业平台有各自版本和许可。

LangChain 与 LangGraph可以组合使用；Google ADK已有图工作流；Eino兼有Agent与显式编排。Python与Go列是不同语言路线，不能把语言偏好直接换算成框架性能分。Deep Agents、LangSmith、AG-UI、A2UI和MCP Apps在本文中按扩展或协议讨论。'''+refs(['S01','S03','S04','S17','S18','S19','S26','S63'])+'。\n')

decision = (BASE/'选型结论与场景指南.md').read_text(encoding='utf-8')
decision = decision.split('## 场景决策表',1)[1]
decision = '## 场景决策\n'+decision
decision = decision.replace('## 为什么复杂系统默认推荐 LangGraph','### 为什么复杂可恢复流程推荐 LangGraph')
decision = decision.replace('## 四个框架的采用与换选条件','### 采用与换选条件')
decision = decision.replace('## 如何把上述结论变成实际决策','### 从推荐到实际决策')
decision = decision.replace('建议采用的前提','建议采用的前提')
decision = decision.replace('第 7 节','本章').replace('说明书相应编号','下文相应编号')
decision = decision.replace('普通循环选 LangChain，复杂可恢复流程选 LangGraph','普通循环选 LangChain，满足显式流程与恢复前提时选 LangGraph')
parts.append(decision)
parts.append('''### 决策优先级与可能改变推荐的证据

LangGraph的默认推荐限定在“显式复杂流程、持久恢复、可接受其运行时、团队能维护编排代码”这组条件。本文优先考虑运行状态与恢复边界能否解释和验收，其次考虑集成与交付成本。本地探针增加了对这一组合的有限信心；ADK/Eino未做同场探针，不能由此推断它们更不稳定。

恢复契约有可解释的差异：LangGraph提供super-step与pending writes的保存契约；Eino的该版本图运行以中断保存为主要checkpoint路径，store需实现，恢复需保持图与调用配置一致；ADK resume文档对工具重复、自定义Agent和开发入口给出限制，不能直接等同于所有2.x图的崩溃恢复。选型应验收实际使用路径。

如果ADK Workflow已覆盖目标流程、恢复与升级验收通过，而且统一session/eval减少工程成本，应优先复用ADK。Go硬约束下，若Eino的目标存储与协议验收通过，应优先Eino。没有特殊拓扑时，LangChain可使用相同底层恢复能力，减少起步代码。推荐是可以被这些证据改变的工程决策。'''+refs(['S06','S19','S21','S27','S28','S73'])+'。\n')

parts.append('''## 比较方法与评分矩阵

### 如何解释分数

分数衡量该项能力的**工程便利程度**。先确认机制或维护中的集成，再看覆盖范围，最后列应用必须完成的工作。数字为本报告的工程判断，引用作者没有给框架这些分数。一个分差不能解释成20%的量化优势。
''')
parts.append(table(['分值','含义'],[
['5','有直接且可组合的常用机制，该项额外建设较少'],
['4','有可复用实现路径，仍有配置、适配或使用限制'],
['3','有基础机制或集成路径，需要明显的应用组合'],
['2','主要由应用或基础设施负责，专门支持有限'],
['1','已确认主要能力有明显缺口；本版不因未找到文档而给1分'],
['U','证据不足或必须同场实测；不是0分，也不代表不支持'],
]))
parts.append('''N 表示框架或同项目SDK；E 表示额外包、协议SDK或服务；A 表示应用自建或治理。`4N+E`表示原生机制加扩展，`2A`表示主要应用责任。E不一定收费，N也需要配置。

证据分为：官方文档/源码、局部实测、待验证。每个比较点给出对应来源与验收方法；完整测试状态集中列在代码章。配置合理并不证明生产安全，接口存在并不证明性能达标。

本版共16类64项。不计算无场景总分；权限、业务正确性等硬约束不能靠其他高分抵消。计算项目权重时还要防止重复计算：checkpoint与短期记忆、流程控制与多Agent、streaming与UI交互之间有关联。

### 常用术语

- **Checkpoint / state / run**：分别指执行记录、运行状态和一次任务；checkpoint保存了什么、何时保存，要以具体实现为准。
- **MCP（Model Context Protocol）/ SDK（Software Development Kit）**：前者用于模型应用接入工具和资源，后者是开发接口与库；接口兼容需按版本确认。
- **HITL（Human-in-the-loop）/ AI2UI**：前者是运行中由人补充或确认，后者在本文泛指Agent与界面交互；A2UI是其中一种具体界面协议。
- **RAG（Retrieval-augmented generation）/ tracing / provider**：分别是检索后生成、记录调用链、具体模型供应商或适配实现。
- **P95 / RSS / GIL**：分别是95%样本不超过的时延、进程驻留内存、CPython解释器锁；三者不能互相替代评价系统性能。
- **RPO / RTO**：分别表示故障恢复可接受的数据损失时间范围、恢复服务所需时间目标。

### 完整矩阵

按编号跳转即可查看定义、各框架分析、引用及验证办法。相同底层能力使用相同分数；高层入口与任意复杂图的控制能力仍分开比较。
''')
for group in groups:
    parts.append(f'#### {group}\n')
    parts.append(table(['比较点','LangChain','LangGraph','Google ADK','Eino'],[
        [f'[{r["id"]} {r["title"]}](#criterion-{r["id"].lower()})']+r['scores'] for r in ROWS if r['group']==group]))

parts.append('## 生命周期能力分析\n\n本章按工程主题展开。每个评分项的验收方法均为建议执行的办法；只有代码章标为实测的局部行为已经执行。\n')
for group in groups:
    lead,takeaway=group_intro[group[0]]
    parts.append(f'### {group}\n\n{lead}\n\n**对选型的影响：** {takeaway}\n')
    for row in (r for r in ROWS if r['group']==group):
        parts.append(f'#### {row["id"]} {row["title"]}\n\n{row["meaning"]}\n')
        for index,(name,score,note) in enumerate(zip(NAMES,row['scores'],row['notes'])):
            nearby=' '+refs(row['note_sources'][index]) if 'note_sources' in row else ''
            parts.append(f'- **{name} · {score}：** {note}{nearby}')
        parts.append('\n依据：'+refs(row['sources'])+'。\n')
        parts.append('**建议验证：** '+row['check']+'\n')
        codes=re.findall(r'C0[1-8]',row['code'])
        if codes:
            scope=re.sub(r'C0[1-8]',lambda m:f'[{m[0]}](#code-{m[0].lower()})',row['code'])
            parts.append('**代码与范围：** '+scope+'。\n')

prior=(BASE/'Agent框架选型说明书-通用版.md').read_text(encoding='utf-8')
boundary=prior.split('## 5. 几个容易混淆的边界',1)[1].split('## 6. 核心代码与验证记录',1)[0]
boundary=re.sub(r'### 5\.[123] ','### ',boundary)
parts.append('## 关键边界与组合方式\n'+boundary)

code = prior.split('## 6. 核心代码与验证记录',1)[1].split('## 7. 最终选型结论与场景决策',1)[0]
code=code.replace('本次执行','2026-10-06执行').replace('同日先前','2026-10-06先前')
code=re.sub(r'\[([^\]]+)\]\(attachments/([^\)]+)\)',lambda m:f'{m.group(1)}：附件内 `{m.group(2)}`',code)
code=code.replace('C01/C02/C05 本次执行','C01/C02/C05 于2026-10-06执行')
parts.append('## 核心代码与实验记录\n'+code)

parts.append('''## 采用前验收与落地步骤

### 分阶段落地

先固定首选与备选、版本和目标组件；用相同模型替身与持久化要求验证机制；再接真实模型与业务工具验证效果；最后验证部署、恢复、权限和运行成本。任何阶段失败都应修正组合或换选。

一个可验收组合至少要列出：编排库、模型/provider、工具/协议adapter、持久化后端、任务调度、鉴权、观测、UI协议与renderer。这样才能避免“选了一个框架”却不知道剩余模块谁负责。

### 必须能改变决策的测试
''')
parts.append(table(['测试','通过条件','当前证据'],[
['跨进程中断恢复','等待记录可读回，输入继续传递到正确步骤','C07仅验证LangGraph+SQLite局部路径'],
['外部操作防重','在远端成功、checkpoint前退出后，无重复业务效果或有明确对账','C07由模拟下游唯一键保证，真实API待测'],
['重复提交与多worker','同一交互至多被有效接受一次，旧worker不能重复执行','C07仅应用SQLite事务20路提交，不是分布式租约'],
['权限撤销与跨租户','恢复和工具执行前重验权限，所有读/列出/删除入口隔离','C05/C07仅局部应用校验'],
['UI交互与断线','多字段输入、页面操作、重复事件与过期表单结果明确','C02/C06没有renderer，待真实前端验收'],
['组件兼容','目标模型的工具/结构化/usage能力，MCP transport和认证均通过','真实模型与MCP未测'],
['升级与回滚','旧等待任务能兼容、迁移或明确拒绝，灰度回滚不丢任务','四框架均未跨版本测试'],
['公平调度与取消','单租户突发时其他租户仍能完成，取消后不启动新操作','未做多副本多租户负载'],
['性能与资源','在业务正确性相同前提下满足时延、错误和资源预算','C08仅短批次合成负载'],
['质量与成本','相同任务/模型多次采样，关键错误人工复核，记录token与费用','没有真实模型效果数据'],
['数据保留与灾备','覆盖状态/日志/文件/记忆/备份，实测RPO/RTO和删除流程','未做部署级演练'],
['离线与供应链','目标环境可构建运行，外联、许可和制品来源可追溯','有实验依赖快照，没有完整安全审计'],
]))
parts.append('''吞吐实验应分成框架开销与端到端两层：前者使用固定mock，后者使用相同真实模型与任务。两层均固定硬件、持久性、节点数与数据规模，记录P50/P95/P99、错误、资源和业务效果。选择最小成本时，要同时计入模型、基础设施、软件产品和自建人力。

### 决策记录与复评条件

采用后保存这组信息：选择及其前提、比较过的备选、决定性证据、仍需建设的模块、已知代价、验收结果和复评触发条件。模型/provider不再兼容、无法满足资源预算、升级导致旧任务无法继续、或某备选显著减少自建成本时，重新评估。此组织方法参考Google的ADR指南；并不意味着Google为本报告的框架结论背书。'''+refs(['S70'])+'。\n')

parts.append('''## 本次文档验收与证据边界

本次整合将场景结论、评分、逐维度理由、来源和核心代码置于同一阅读文档，新增发布与数据治理8项，并再次修正继承能力与安全等依据不足的分差。逐项改动记录、独立review输入和完整校验结果位于附件的 `review/` 与 `metadata/`。

已经检查UTF-8、所有内部目标、矩阵与正文数据一致性、附件引用、代码语法及压缩包校验。浏览器验收检查文首、矩阵、长段落与窄屏布局；打印规则另做样式检查，尚未逐页验证纸面输出。文档验收与框架生产验收分开：ADK/Eino代码状态及真实模型、renderer、多副本实验的缺口均按原证据保留。

### 资料组织参考

Microsoft的选型指南按需求与场景组织比较，并明确技术、运维、安全及团队因素；Google的ADR指南强调记录决策背景、选项和后果。本文借用这种组织方法，评分和Agent结论由本报告负责。'''+refs(['S70','S71'])+'。\n')

# Add independently collected domestic/international writing examples without making them Agent evidence.
example_file=BASE/'review-inputs'/'doc-examples.md'
if example_file.exists():
    example_text=example_file.read_text(encoding='utf-8')
    seen=set(s['url'] for s in sources.values())
    cases=[]
    for case in re.split(r'(?=^## \d+\.)',example_text,flags=re.M):
        heading=re.search(r'^## \d+\. (.+)$',case,re.M)
        link=re.search(r'\[[^\]]+\]\((https?://[^)]+)\)',case)
        if not heading or not link:continue
        label,url=heading[1],link[1]
        if url in seen: continue
        seen.add(url)
        cases.append([label,f'[{label}]({url})','仅参考选型组织与表达，不作为Agent能力证据'])
    if cases: parts.append(table(['案例','链接','适用边界'],cases[:6]))

parts.append('## 来源与附件\n\n在线文档会变化。来源索引保留精确URL和访问日期；固定版本源码以URL中的版本为准。本次不宣称已离线归档所有网页。S15等第三方集成只代表其维护方，不能视为核心团队支持承诺；S54/S55包含Experimental标记；S29旧版参考由S67核对当前基线。\n')
for key,s in sources.items():
    parts.append(f'### {key} {s["title"]}\n\n[{s["title"]}]({s["url"]}) · 访问 {s["access_date"]} · {s["evidence_type"]}\n')
parts.append('''### 唯一附件

下载同目录的 **[Agent框架选型附件.zip](Agent框架选型附件.zip)**。解压后包含：

- `code/`：完整示例、运行说明、实验依赖快照和原始结果。
- `metadata/`：64项评分数据、来源索引、验收结果与文件hash。
- `review/`：独立案例收集、独立技术复核与本次决策修正记录。
- `source/`：本文可编辑Markdown和生成程序。阅读本文不依赖这些文件。

文档可直接在浏览器离线打开；引用的在线资料需联网查看。HTML内置样式，不加载外部字体或脚本。打印时隐藏目录与工具栏，保留全部正文及代码。
''')

markdown='\n\n'.join(parts)
markdown=markdown.replace('A2UI 要分成几个不同能力','AI2UI：区分运行交互与界面协议').replace('证明完成了 A2UI','证明完成了 AI2UI')
markdown=markdown.replace('证据分为：官方文档/源码、局部实测、待验证。','证据分为：D（官方文档/源码）、T（局部实测）、U（待验证）。')
assert not any(x in markdown for x in ['Roma','SCP','Qwen'])
assert len(ROWS)==64 and len(groups)==16
for r in ROWS:
    assert len(r['scores'])==len(r['notes'])==4
    assert all(s in sources for s in r['sources']),(r['id'],r['sources'])

# Standard Markdown parser plus stable HTML ids in the standalone HTML renderer.
parser=MarkdownIt('commonmark',{'html':False}).enable('table')
tokens=parser.parse(markdown)
toc=[]
ids=set()
for i,token in enumerate(tokens):
    if token.type!='heading_open': continue
    title=tokens[i+1].content
    criterion=re.match(r'^([A-P][1-4]) ',title)
    source=re.match(r'^(S\d+) ',title)
    code_match=re.match(r'^(C0[1-8]) ',title)
    if criterion: ident='criterion-'+criterion[1].lower()
    elif source: ident='source-'+source[1].lower()
    elif code_match: ident='code-'+code_match[1].lower()
    else: ident='section-'+hashlib.sha1((token.tag+title).encode()).hexdigest()[:10]
    assert ident not in ids,ident
    ids.add(ident)
    token.attrSet('id',ident)
    if token.tag=='h2':toc.append((ident,title))
    elif token.tag=='h3' and re.match(r'^[A-P] ',title):toc.append((ident,title))
body=parser.renderer.render(tokens,parser.options,{})
body=re.sub(r'<table>', '<div class="table-scroll" tabindex="0" role="region" aria-label="比较表格"><table>',body)
body=body.replace('</table>','</table></div>')
body=re.sub(r'(?<![\w/])([1-5])([NEA](?:\+[NEA])*)(?=[:：<\s])',r'\1\2',body)
nav=''.join(f'<a href="#{ident}" class="{"sub" if re.match(r"^[A-P] ",title) else ""}">{html.escape(title)}</a>' for ident,title in toc)
styles=(BASE/'internal'/'document.css').read_text(encoding='utf-8')
script=(BASE/'internal'/'document.js').read_text(encoding='utf-8')
document=f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>企业级 AI Agent 框架选型说明书</title><meta name="description" content="四框架、16类64项比较、场景推荐、证据与验收。">
<style>{styles}</style></head><body>
<a class="skip" href="#main">跳转到正文</a>
<header><div class="brand">技术决策指南 <span>AI Agent Frameworks</span></div><div class="tools"><a href="Agent框架选型附件.zip" download>下载附件</a><button id="print-button" type="button">打印文档</button></div></header>
<aside aria-label="文档目录"><div class="nav-title">本文目录</div>{nav}<p class="nav-help">Ctrl / ⌘ + F 搜索全文</p></aside>
<main id="main"><div class="doc-meta">通用选型 · 版本 2.0 · 2026-10-07</div>{body}<footer>资料与实验的边界已在正文注明。所有完整代码与复现材料位于唯一附件。</footer></main>
<script>{script}</script></body></html>'''
OUT.mkdir(exist_ok=True)
STAGE.mkdir(parents=True,exist_ok=True)
write(OUT/'Agent框架选型说明书.html',document)
write(STAGE/'source'/'Agent框架选型说明书.md',markdown)
shutil.copytree(BASE/'attachments',STAGE/'code',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
write(STAGE/'metadata'/'comparison-data.json',json.dumps(ROWS,ensure_ascii=False,indent=2))
write(STAGE/'metadata'/'sources.json',json.dumps(sources,ensure_ascii=False,indent=2))
if (BASE/'review-inputs').exists():shutil.copytree(BASE/'review-inputs',STAGE/'review',dirs_exist_ok=True)
for filename in ['build_delivery.py','delivery_additions.py','document.css','document.js']:
    shutil.copyfile(BASE/'internal'/filename,STAGE/'source'/filename)
shutil.copyfile(BASE/'comparison_data.py',STAGE/'source'/'comparison_data_original.py')
write(STAGE/'review'/'integration-decisions.json',json.dumps(changes,ensure_ascii=False,indent=2))
write(STAGE/'README.md','''# 附件使用说明

本附件属于同目录的Agent框架选型说明书.html。正文已含结论、矩阵、解释和来源；附件供复现与编辑。

code包含完整代码与原始实验记录，请先读code/README.md。C03未运行，C04未编译。其他实验以2026-10-06记录为准，整合没有重新测量生产性能。

metadata包含评分、来源、验收记录与hash。review包含独立review输入，部分建议经主报告判断后采纳，不能把review草稿直接当结论。

source包含本文Markdown及生成程序。浏览器阅读不需要安装依赖；再生成程序需要Python和markdown-it-py==4.0.0。该程序依赖研究工作目录的材料组织，不是一个安装框架的生产脚手架。source中的Markdown可独立编辑。

不要将附件中的示例身份字段、SQLite事务或固定模型替身当作生产认证、分布式互斥或模型质量证明。
''')

class Inspector(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.links=[];self.external_assets=[];self.tables=0
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.append(attrs['id'])
        if tag=='a':self.links.append(attrs.get('href',''))
        if tag in ['script','link','img','iframe'] and ('src' in attrs or 'href' in attrs):self.external_assets.append(attrs)
        if tag=='table':self.tables+=1

inspector=Inspector();inspector.feed(document)
assert len(inspector.ids)==len(set(inspector.ids))
assert not inspector.external_assets
for link in inspector.links:
    if link.startswith('#'):assert link[1:] in inspector.ids,link
    else:assert link.startswith(('https://','http://')) or unquote(link)=='Agent框架选型附件.zip',link
assert '\ufffd' not in document
assert not any(unicodedata.category(c) in ['Cc','Cf'] and c not in '\n\r\t' for c in document)
assert len([i for i in inspector.ids if i.startswith('criterion-')])==64
assert len([i for i in inspector.ids if i.startswith('code-')])==8
for row in ROWS:
    section=markdown.split(f'#### {row["id"]} {row["title"]}',1)[1].split('\n#### ',1)[0].split('\n### ',1)[0]
    for name,score,note in zip(NAMES,row['scores'],row['notes']):
        assert f'**{name} · {score}：** {note}' in section,row['id']
    assert f'[{row["id"]} {row["title"]}](#criterion-{row["id"].lower()})' in markdown
    assert ' | '.join(row['scores']) in markdown
for f in (STAGE/'code').rglob('*.py'):ast.parse(f.read_text(encoding='utf-8'))
for f in (STAGE/'code'/'results').glob('*.json'):json.loads(f.read_text(encoding='utf-8'))
verification=dict(date='2026-10-07',revision='2.0',criteria=64,frameworks=4,groups=16,sources=len(sources),
    internal_links='passed',encoding='passed',matrix_and_analysis='passed',python_syntax='passed',
    no_external_reading_assets=True,tables=inspector.tables,
    document_sha256=hashlib.sha256(document.encode()).hexdigest(),
    browser_acceptance='pending',runtime_evidence='Reused 2026-10-06 records; ADK/Eino not run')
browser_record=BASE/'internal'/'browser-acceptance.json'
if browser_record.exists():
    verification['browser_acceptance']=json.loads(browser_record.read_text(encoding='utf-8'))
write(STAGE/'metadata'/'document-verification.json',json.dumps(verification,ensure_ascii=False,indent=2))
manifest=[]
for file in STAGE.rglob('*'):
    if file.is_file() and file.name!='file-manifest.json':
        manifest.append(dict(path=file.relative_to(STAGE).as_posix(),size=file.stat().st_size,sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
write(STAGE/'metadata'/'file-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(OUT/'Agent框架选型附件.zip','w',zipfile.ZIP_DEFLATED) as z:
    for file in sorted(STAGE.rglob('*')):
        if file.is_file():z.write(file,file.relative_to(STAGE))
with zipfile.ZipFile(OUT/'Agent框架选型附件.zip') as z:
    assert z.testzip() is None
    for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
assert {p.name for p in OUT.iterdir()}=={'Agent框架选型说明书.html','Agent框架选型附件.zip'}
print(json.dumps(verification,ensure_ascii=False))
