// Optional reading conveniences; all text and links work without JavaScript.
document.getElementById('print-button').addEventListener('click',()=>window.print());
const navLinks=[...document.querySelectorAll('aside a')];
const navById=new Map(navLinks.map(a=>[a.getAttribute('href').slice(1),a]));
const headings=[...document.querySelectorAll('h2,h3')].filter(h=>navById.has(h.id));
let scheduled=false;
function updateNav(){
  scheduled=false;
  let current=headings[0];
  for(const h of headings){if(h.getBoundingClientRect().top<=115)current=h;else break;}
  const active=current&&navById.get(current.id);
  if(!active)return;
  navLinks.forEach(a=>{a.classList.toggle('active',a===active);if(a===active)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});
}
window.addEventListener('scroll',()=>{if(!scheduled){scheduled=true;requestAnimationFrame(updateNav);}},{passive:true});
window.addEventListener('hashchange',updateNav);
updateNav();
