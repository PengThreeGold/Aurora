# 官方选型文档案例与可借鉴结构

核验日期：2026-10-07。以下均为厂商官方文档；借鉴的是组织方式，不把厂商产品推荐或性能宣传直接用于 Agent 框架打分。

## 1. Microsoft：Choose an Azure compute service

[官方原文](https://learn.microsoft.com/en-us/azure/architecture/guide/technology-choices/compute-decision-tree)

结构：范围说明 → flowchart 筛候选 → 基本能力与 hosting models → networking、DevOps、团队技能与运维负担、扩展、安全等比较表 → limits 与 cost → 特殊场景 → 下一步。

值得借鉴：flowchart 输出是候选，之后还要核对具体约束；一个系统允许组合多种服务。每组比较表只回答一个问题，附条件说明，避免把“支持”误读为所有部署形态都支持。

不能套用：Azure 产品间的托管责任、规格上限和价格不能移植到开源 Agent 框架。文档中的分类也不等于量化性能排名。

对本说明书的建议：先展示框架选择路径，承认 LangChain 与 LangGraph 可组合；再解释开发与运行负担。

## 2. Google：Multicloud database management: Architectures, use cases, and best practices

[官方原文](https://docs.cloud.google.com/architecture/multi-cloud-database-management)

结构：读者与范围 → key terms → use cases → deployment patterns → database system categorization → 选择 decision trees → deployment best practices。

值得借鉴：先根据问题挑选真正相关的分类维度；先问现有系统是否应保留；新系统与迁移系统走不同决策路径。选择结果还要通过应用通信和延迟 benchmark 验证。

不能套用：数据库分布模型和复制关系不等于 Agent checkpoint 语义，不能拿复制能力替代副作用恢复的判断。

对本说明书的建议：先解释高层 Agent API 与底层 workflow 的不同，把“框架机制”“扩展组件”“应用责任”分开；只迁移有明确收益的部分。

## 3. 阿里云：如何选择阿里云数据库服务

[官方原文](https://help.aliyun.com/zh/decision-guides/how-to-choose-database-service)

结构：产品类型与适用场景 → 按关系型、NoSQL、数据仓库展开选型考虑 → 引擎、性能、成本、扩展、可靠性、安全、易用性等问题 → 具体产品和功能入口。

值得借鉴：同一需求有多个实现方案，解释额外同步链路、运维负担和适用限制；把扩展能力、扩展耗时、扩展影响分开。

不能套用：开头市场宣传、旧年度行业报告和缺少相同测试条件的性能倍数，不适合作为独立框架评估证据。

对本说明书的建议：把“并发 API”“部署扩展”“真实吞吐”分开；展示额外组件带来的工程成本。

## 4. 华为云：数据库服务决策指南

[官方原文](https://support.huaweicloud.com/how-to-choose-databases/db_0001.html)

结构：服务全景 → 典型应用场景 → 数据模型、负载、性能、扩展、一致性、兼容性横向表 → 四个决策示例 → 快速入门和实践。

值得借鉴：给出明确首选和备选，用“需求分析 → 表格匹配 → 推荐组合”的例子说明结论如何得到。

不能套用：厂商自家产品的优势宣传和没有环境说明的 QPS 描述不能变成框架分数。

对本说明书的建议：至少给出聊天工具型、复杂可恢复流程、Google 生态、Go 交付四个场景；每个场景包括首选、理由、代价和换选条件。

## 5. 华为云：存储云服务选型指导

[官方原文](https://support.huaweicloud.com/intl/zh-cn/how-to-choose-storage/storage_0001.html)

结构：服务类别 → 七个关键决策维度 → 每个维度的含义、要问的问题、要收集的业务信息 → 匹配存储方案。

值得借鉴：比较维度不是名词清单，而是能回答问题、能收集输入的信息。把数据类型、访问方式和工作负载说清楚后再选产品。

不能套用：存储协议和具体存储性能指标不适用于 Agent orchestration，应该换成可观察的任务行为。

对本说明书的建议：每个维度说明“它影响什么”“如何比较”“什么证据足够”“如何验收”；定义真实模型、外部工具、checkpoint、UI 输入和故障位置。

## 建议主文档阅读顺序

1. 适用范围、版本与结论：读者先知道本文帮助做什么决定。
2. 场景推荐和换选条件：给明确可执行结果。
3. 框架职责与组合方式：解释为什么四个候选并非完全互斥。
4. 比较规则和逐项矩阵：分数定义、来源、未验证项目。
5. 按决策主题展开：每组先解释实际影响，再对照框架差异和关键代码；保留全部比较点，控制重复。
6. demo 与结果：验证了什么、没有验证什么；核心代码进正文，完整代码与原始结果放唯一附件。
7. 生产验收和重新评估条件：运行故障、隔离、升级、成本达到什么标准才接受选型。
8. 统一来源索引：官方入口与本地实验来源独立编号。

具体修改标准：避免原始 HTML 锚点；表格之外要有连贯解释；缩写首次出现给完整含义；分数不混入实測吞吐；结论随场景说明，不能只有“视情况而定”；“暂未验证”与“不支持”分开。
