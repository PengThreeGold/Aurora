# 独立复核：评分、证据与选型结论

复核日期：2026-10-07。范围为通用版说明书、评分数据、场景指南及官方机制资料。未读取背景资料。本记录供主文档编辑使用，不是额外交付文档。

## 最先需要改的项目

| 项目 | 问题与影响 | 可执行修改 |
|---|---|---|
| D4 执行历史 | LangChain 3、LangGraph 4，但 create_agent 返回 compiled graph，继承相同的历史接口；正文没有给出操作成本差异 | 对齐底层能力分，保留高层循环与任意图的表达区别。升级兼容在 J1 讨论，避免同一行混入两个独立能力 |
| E1 Streaming | LangChain 4、LangGraph 5，但官方 LangChain 页面直接展示 updates/messages/custom 与多模式输出 | 同分；把 parent graph 的 subgraphs=True 等具体配置写入限制，不以高层封装推断缺少事件能力 |
| E4 UI 恢复 | LangChain 2、LangGraph 3；双方同样能依据 checkpoint 重建业务状态，同样不自动提供 UI snapshot/事件日志 | LangChain 与 LangGraph 同分。ADK/Eino 有基础状态记录但未经同场 UI 恢复验证，分差需精确说明机制与额外工作 |
| G3 取消 | LangChain 3、LangGraph 4，未指出独有能力或不同机制 | 对齐继承机制；同时把取消、主动保存后暂停、后台生命周期三个行为分开解释 |
| C4 Eino 上下文隔离 | 对特定 Workflow 全历史共享的限制虽已准确限定，但仍作为整个 Eino 3 分的主要理由 | Eino 官方 AgentTool 默认只传模型生成的请求参数，完整历史需显式启用。Eino 改为 4N+A，说明 AgentTool 与 Workflow 两条路径 |
| C4 其他分差 | LangGraph 5 主要据 state 输入映射，其他方案也可显式限制模型输入，未测成本 | 建议四者均 4N+A；如保留 LangGraph 5，必须把该行改为明确的“子图 state 接口与输入输出映射”，不能推导安全隔离更强 |
| F4 安全 | Prompt injection 与 sandbox 是两项能力；ADK 安全指南和 callbacks 不足以证明其整体安全高一分 | 不保留笼统的安全优势。明确 ADK 的 Model Armor Plugin 和 Vertex Code Interpreter 是外部产品路径；可同分，并分述两种责任 |
| AI2UI 场景推荐 | 容易让读者以为 LangGraph 对 UI 协议原生支持更好 | 写成“复杂后端流程采用 LangGraph，UI 协议另选”；单纯因为 UI 不应重写已有 ADK/Eino 后端 |

## 可以支持明确推荐的真实差异

**明确给出 LangGraph 的场景推荐是合理的工程意见，但不能写成四框架已实测优胜。** 其依据应具体到状态保存与恢复契约，而不仅是“图编排可控”；ADK 和 Eino 也有图，C1 已给三者相同分数。

建议使用以下结论：

> 对需要显式控制业务分支、等待人工输入、在进程退出后继续执行的系统，在目标语言与部署条件允许、团队愿意维护 state 和节点边界时，推荐 LangGraph 作为编排核心，并复用需要的 LangChain 组件。这个推荐依据其明确的 checkpoint 与 replay 契约及本次完成的局部探针。ADK Workflow 和 Eino compose 是可替代路线；若其目标存储与故障恢复实验通过，或者已有团队能力显著降低维护成本，可以改选。性能与生产可靠性尚未形成四框架比较结果。

### Eino 的关键限制

官方 Interrupt & CheckPoint 文档说明，中断后保存状态，存储接口由使用者实现，恢复要求图编排保持一致，并重新传入相应 CallOptions。v0.9.21 的普通运行循环完成任务后没有逐步持久保存；`handleInterrupt` 路径才构造并保存 checkpoint。由此可以区分“有中断后恢复机制”和“默认每步具有 crash recovery”，这是 D1 的有效比较内容。

这不意味着 Eino 不能做长期任务恢复；可以自行设计保存边界与存储。对 Go 场景仍可推荐 Eino，同时应验收强杀窗口、外部副作用防重和接管行为。

来源：[Interrupt & CheckPoint](https://www.cloudwego.io/docs/eino/core_modules/chain_and_graph_orchestration/checkpoint_interrupt/)、[v0.9.21 graph_run.go](https://raw.githubusercontent.com/cloudwego/eino/v0.9.21/compose/graph_run.go)。

### ADK 的关键限制

官方 Resume 文档明确：工具是 at least once，恢复时可能重复；停止后修改 workflow 不受支持；Custom Agent 默认不支持 Resume，需要自行实现状态保存；ADK Web/CLI 不支持该故障恢复操作。应分别说明 API server/Runner resume、RequestInput 人工继续和 Web 开发表单，不能混成一个无条件“恢复支持”。

2.x 图首页并未给出与传统 template workflow 完全相同的恢复契约。本次未运行锁定版本的组合验证，所以不应把两个页面拼接为已验证的 2.x graph crash recovery。

来源：[Resume stopped agents](https://adk.dev/runtime/resume/)、[Graph-based workflows](https://adk.dev/graphs/)。

### LangChain 的继承能力

官方 Streaming 页面展示 `create_agent` 的 messages、updates、custom 多模式输出；该 Agent 是 compiled graph。当前实验环境也确认 CompiledStateGraph 存在 get_state/get_state_history/update_state/stream/ainvoke。对应能力不能因高层入口而减少底层分数。任意复杂业务拓扑的直接表达，可以作为 C1/C2 或起步便利度的独立区别。

来源：[LangChain Streaming](https://docs.langchain.com/oss/python/langchain/streaming)、[LangChain overview](https://docs.langchain.com/oss/python/langchain/overview)。本地检查仅检查方法存在，不是完整历史与取消验收。

### Eino 的上下文输入路径

官方 AgentTool 文档：默认只传模型生成的请求参数，`WithFullChatHistoryAsInput()` 才使用父 Agent 完整历史，`WithAgentInputSchema()` 可以约束输入。Workflow 的共享历史限制因此只能影响特定组合，不能覆盖所有协作路径。

来源：[Agent Collaboration](https://www.cloudwego.io/docs/eino/core_modules/eino_adk/agent_collaboration/)。

## 评分和阅读方式还应改善

1. **把分数性质放在矩阵旁。** 数字是工程便利度判断，没有实测的工时或生产质量。N/E/A 表示实现责任，不应同时充当事实可信度；另显示“官方资料 / 本地实测 / 待验证”。
2. **高分不应抵消硬约束失败。** 租户越权、重复外部操作、目标模型不兼容、必要许可证不满足应直接使具体组合失败，即使其他行分高。
3. **B1 的 5 对 4 仍是弱分差。** 没有 provider 覆盖统计或目标 provider 清单，不能从品牌生态印象推出覆盖冠军。保留分差时给出具体组件路径，把该分标为工程判断；公平的同场测试按同一模型功能清单比较。
4. **N1 多模态不要由接口介绍拉出质量差距。** Eino 有多模态接口，AgenticModel 文档也明确 ordered ContentBlocks，但该文档基于 main 且标 Beta，不可直接归入 v0.9.21 已验收。建议不要仅凭文档篇幅给 Eino 更低分。
5. **证据要贴近对应事实。** 一行四框架下面放一串来源能追溯，但阅读成本高；把关键差异后面直接关联相应链接，用户能立即检验分差。
6. **实测与示例状态保持诚实。** LangChain/LangGraph 本地示例通过；ADK 未运行、Eino 未编译。不能因为完成文档整合而把状态变为“全部验收通过”。
7. **生命周期缺项的补充方向正确。** CI/CD、版本配置、任务调度、排空、工件、删除、备份灾备、工具版本应逐项列出，分别说明 framework 与应用/平台责任。

## 文档验收应检查的内容

- 一份主文档内同时存在可执行结论、矩阵、解释、核心代码、来源和验收边界，阅读不依赖旧的多个 Markdown 文件。
- 所有分差有解释；同一底层机制在 LangChain/LangGraph 中不产生无理由差距。
- UI 协议、renderer、Agent runtime 和治理服务的职责清楚，示例没有被写成完成集成。
- HTML 代码片段正确转义；中文 UTF-8 正常；内部跳转、代码附件入口、打印版可读。
- 推荐含采用前提、替代路线和可以推翻推荐的实验，既给结论又保留证据边界。
