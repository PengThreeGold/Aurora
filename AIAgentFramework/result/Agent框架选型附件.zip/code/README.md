# 代码附件与复现实验

这些例子用于解释机制，互相不是相同的端到端benchmark。全部使用合成数据，无真实模型/云服务凭据。C01、C02、C05本版实际运行；C07/C08复用2026-10-06同一研究会话的通用实验脚本与原始记录，未重新采样。主报告不使用业务背景权重。

| 编号 | 文件 | 状态 |
|---|---|---|
| C01 | langchain_tool_demo.py | 已运行；真实LangChain create_agent / Tool |
| C02 | langgraph_form_demo.py | 已运行；真实LangGraph，内存checkpoint |
| C03 | adk_input_demo/agent.py | 仅语法检查；未安装/运行ADK |
| C04 | eino_graph_demo/main.go | 未编译；Go工具链不可用；无go.sum |
| C05 | application_boundary_demo.py | 已运行；应用策略，不是框架能力 |
| C06 | ui_event_example.json | JSON示意；不是公开协议的实现 |
| C07 | langgraph_probe.py | 已运行；独立进程恢复/应用防重，原记录复用 |
| C08 | concurrency_probe.py | 已运行；TCP mock / SQLite合成负载，原记录复用 |

## Python已测样例

在本附件目录创建独立venv，安装 `requirements-tested.lock.txt` 后运行：

```powershell
python -m venv .venv
.venv/Scripts/python -m pip install -r requirements-tested.lock.txt
.venv/Scripts/python langchain_tool_demo.py
.venv/Scripts/python langgraph_form_demo.py
.venv/Scripts/python application_boundary_demo.py
.venv/Scripts/python langgraph_probe.py
.venv/Scripts/python concurrency_probe.py
```

实验环境Python3.14.6、Windows、LangChain1.4.3、LangGraph1.2.13。freeze是实验环境快照，不是跨所有OS/Python版本验证的发布锁文件，也不含hash。C07有意终止其启动的子进程；C08会监听127.0.0.1临时端口。两个脚本在临时目录使用SQLite并输出JSON；发布记录存于results。本版只调整了复用脚本的输出路径以适配附件目录，实验逻辑未变。再次运行会更新各自results文件。

## Google ADK未运行示例

在另一个独立环境安装 `google-adk==2.11.0`，从本附件目录运行 `adk web`，选择adk_input_demo；输入1到30中的整数，预期得到两倍数值。这是开发UI路径，不是生产renderer。参照官方 https://adk.dev/graphs/human-input/ 编写并增加输入范围检查。未验证此机器的依赖安装、交互路由或跨进程恢复。

## Eino未编译示例

进入eino_graph_demo，用满足该版本go.mod要求的工具链执行 `go mod tidy` 和 `go run .`。预期输出14。go.mod固定Eino v0.9.21；未在本机解析依赖，无go.sum，不能声明可复现构建已通过。程序只测typed graph，不测Agent、checkpoint、模型或并发。

## 限制

所有例子缺少生产网关、token认证、可靠事件队列、完整renderer和真实租户数据库。不要把示例中的thread_id、租户名或白名单检查当成完整隔离系统；不要把一次mock成功当作模型效果或公开协议兼容证明。
