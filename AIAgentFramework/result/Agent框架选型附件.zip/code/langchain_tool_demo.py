"""C01: actual LangChain agent loop with a deterministic local model, no network."""
import json
from pathlib import Path
from typing import Any
from langchain.agents import create_agent
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import tool


class ScriptedModel(BaseChatModel):
    @property
    def _llm_type(self):
        return 'local-scripted-model'

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs: Any):
        if isinstance(messages[-1], ToolMessage):
            reply = AIMessage(content=f"Result: {messages[-1].content}")
        else:
            reply = AIMessage(content='', tool_calls=[{'name':'double_number', 'args':{'number':7}, 'id':'call-1', 'type':'tool_call'}])
        return ChatResult(generations=[ChatGeneration(message=reply)])


@tool
def double_number(number: int) -> int:
    """Multiply an integer by two."""
    return number * 2


def main():
    # BEGIN CORE
    agent = create_agent(model=ScriptedModel(), tools=[double_number])
    result = agent.invoke({'messages':[{'role':'user','content':'Double 7'}]})
    # END CORE
    assert result['messages'][-1].content == 'Result: 14'
    assert any(isinstance(m, ToolMessage) for m in result['messages'])
    record = {'passed':True, 'output':result['messages'][-1].content,
              'scope':'Real create_agent/tool execution; deterministic stub, not model-quality evidence'}
    out = Path(__file__).parent / 'results/langchain-tool.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
