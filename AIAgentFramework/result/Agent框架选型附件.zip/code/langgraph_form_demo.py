"""C02: actual LangGraph structured interrupt, local in-memory demonstration only."""
import json
from pathlib import Path
from typing import TypedDict
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt


class State(TypedDict, total=False):
    answer: dict


# BEGIN CORE
def collect(state):
    value = interrupt({'form':'query', 'fields':['region','days']})
    if set(value) != {'region','days'} or type(value['days']) is not int:
        raise ValueError('Unexpected fields or days type')
    if value['region'] not in ['east','west'] or not 1 <= value['days'] <= 30:
        raise ValueError('Invalid form values')
    return {'answer':value}
# END CORE


def main():
    builder = StateGraph(State)
    builder.add_node('collect',collect)
    builder.add_edge(START,'collect')
    builder.add_edge('collect',END)
    graph = builder.compile(checkpointer=InMemorySaver())
    config = {'configurable':{'thread_id':'local-demo'}}
    first = graph.invoke({},config)
    assert first['__interrupt__']
    result = graph.invoke(Command(resume={'region':'east','days':7}),config)
    assert result['answer'] == {'region':'east','days':7}
    record = {'passed':True,'answer':result['answer'],
              'scope':'No LLM/renderer; InMemorySaver does not survive restart'}
    out = Path(__file__).parent / 'results/langgraph-form.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
