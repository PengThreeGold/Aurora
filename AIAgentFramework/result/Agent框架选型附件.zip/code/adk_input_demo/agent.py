"""C03: ADK 2.11 API example, NOT executed in this study.

In an isolated environment install google-adk==2.11.0, then run
`adk web` from the attachments directory and select adk_input_demo.
This is a developer UI example, not a production UI or durability test.
"""
from google.adk import Workflow
from google.adk.events import RequestInput


# BEGIN CORE
def ask_number():
    yield RequestInput(message='Enter an integer from 1 to 30')


def calculate(node_input):
    value = int(node_input)
    if not 1 <= value <= 30:
        raise ValueError('Value must be from 1 to 30')
    return value * 2


root_agent = Workflow(name='input_demo', edges=[('START',ask_number,calculate)])
# END CORE
