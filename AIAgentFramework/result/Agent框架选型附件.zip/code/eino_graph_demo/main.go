// C04: Eino graph example. Not compiled here because Go is unavailable.
// Run `go mod tidy` and `go run .` with a compatible Go toolchain.
package main

import (
    "context"
    "fmt"
    "github.com/cloudwego/eino/compose"
)

func main() {
    ctx := context.Background()
    // BEGIN CORE
    graph := compose.NewGraph[int, int]()
    err := graph.AddLambdaNode("double", compose.InvokableLambda(
        func(ctx context.Context, input int) (int, error) {
            if input < 1 || input > 30 {
                return 0, fmt.Errorf("input must be from 1 to 30")
            }
            return input * 2, nil
        }))
    // END CORE
    if err != nil { panic(err) }
    if err := graph.AddEdge(compose.START, "double"); err != nil { panic(err) }
    if err := graph.AddEdge("double", compose.END); err != nil { panic(err) }
    runnable, err := graph.Compile(ctx)
    if err != nil { panic(err) }
    output, err := runnable.Invoke(ctx, 7)
    if err != nil { panic(err) }
    if output != 14 { panic("unexpected result") }
    fmt.Println(output)
}
