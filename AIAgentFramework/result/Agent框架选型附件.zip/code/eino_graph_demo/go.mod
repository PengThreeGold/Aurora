module example.com/framework-comparison/eino-graph-demo

go 1.23.0

require github.com/cloudwego/eino v0.9.21
