"""Synthetic real-LangGraph I/O probe, not a cross-framework benchmark or sizing SLA."""
import asyncio
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import statistics
import sys
import tempfile
import time
from typing import TypedDict

import psutil
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver


class State(TypedDict):
    value: int


async def experiment(concurrency, cpu_work, repeat):
    async def handler(reader, writer):
        try:
            await reader.readline()
            await asyncio.sleep(0.05)  # mock upstream service latency
            writer.write(b'1\n')
            await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(handler, '127.0.0.1', 0)
    port = server.sockets[0].getsockname()[1]
    async def node(state):
        reader, writer = await asyncio.open_connection('127.0.0.1', port)
        writer.write(b'query\n')
        await writer.drain()
        await reader.readline()
        writer.close()
        await writer.wait_closed()
        if cpu_work:
            # Intentionally bad: pure Python CPU on the event loop, blocking ALL requests.
            sum(i * i for i in range(150000))
        return {'value': state['value'] + 1}

    process = psutil.Process()
    rss_start = process.memory_info().rss
    peak = rss_start
    lags = []
    stop = asyncio.Event()
    async def monitor():
        nonlocal peak
        while not stop.is_set():
            start = time.perf_counter()
            await asyncio.sleep(0.005)
            lags.append(max(0, time.perf_counter() - start - 0.005))
            peak = max(peak, process.memory_info().rss)

    try:
        with tempfile.TemporaryDirectory(prefix='roma-load-') as folder:
            async with AsyncSqliteSaver.from_conn_string(str(Path(folder) / 'cp.sqlite')) as saver:
                builder = StateGraph(State)
                previous = START
                for n in range(4):
                    name = f'step{n}'
                    builder.add_node(name, node)
                    builder.add_edge(previous, name)
                    previous = name
                builder.add_edge(previous, END)
                graph = builder.compile(checkpointer=saver)
                # Warm imports, database setup and graph paths before measuring.
                await graph.ainvoke({'value': 0}, {'configurable': {'thread_id': 'warm'}}, durability='sync')
                durations = []
                async def run(i):
                    start = time.perf_counter()
                    result = await graph.ainvoke({'value': 0}, {'configurable': {'thread_id': f'tenant-{i}/run'}}, durability='sync')
                    assert result['value'] == 4
                    durations.append(time.perf_counter() - start)
                watcher = asyncio.create_task(monitor())
                cpu_start = time.process_time()
                start = time.perf_counter()
                try:
                    await asyncio.gather(*(run(i) for i in range(concurrency)))
                finally:
                    elapsed = time.perf_counter() - start
                    cpu_seconds = time.process_time() - cpu_start
                    stop.set()
                    await watcher
                durations.sort()
                return {'concurrency': concurrency, 'cpu_in_node': cpu_work, 'repeat': repeat,
                        'wall_s': round(elapsed, 4), 'p50_s': round(statistics.median(durations), 4),
                        'p95_s': round(durations[math.ceil(len(durations)*.95)-1], 4),
                        'completed_per_s': round(concurrency/elapsed, 3), 'process_cpu_s': round(cpu_seconds, 4),
                        'peak_rss_mib': round(peak/1024**2, 2),
                        'event_loop_max_lag_ms': round(max(lags, default=0)*1000, 2)}
    finally:
        server.close()
        await server.wait_closed()


async def main():
    samples = []
    for cpu in [False, True]:
        for n in [10, 50]:
            for repeat in range(3):
                samples.append(await experiment(n, cpu, repeat))
    result = {'python': sys.version, 'gil_enabled': sys._is_gil_enabled() if hasattr(sys, '_is_gil_enabled') else 'default',
              'platform': platform.platform(), 'logical_cpus': os.cpu_count(),
              'langgraph': importlib.metadata.version('langgraph'), 'samples': samples,
              'limitations': ['Closed-loop burst, 3 repetitions, not a sustained open-loop SLA test',
                             'Mock upstream TCP in same process; no LLM/API quota/TLS/MCP/UI',
                             'Shared SQLite writer and Windows host, not Linux container/PostgreSQL',
                             'RSS includes mock server; excludes real MCP service/databases/model',
                             'CPU scenario proves event-loop blocking, not an isolated GIL comparison']}
    output = Path(__file__).parent / 'results' / 'concurrency-probe.json'
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())
