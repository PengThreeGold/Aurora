"""C05/C06: framework-independent application policy and UI-intent example.

Not an implementation of AG-UI or A2UI and not a complete security system.
The authenticated identity is passed separately from the untrusted event body.
"""
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Identity:
    tenant: str
    user: str


# BEGIN CORE
def authorize(identity, owner, event, current_revision, visible_resources):
    if identity != owner:
        raise PermissionError('Wrong owner')
    if set(event) != {'revision','action','resource_id'}:
        raise ValueError('Unexpected event fields')
    if event['revision'] != current_revision:
        raise ValueError('Stale interaction')
    if event['action'] not in {'open_detail','submit_query'}:
        raise PermissionError('Action is not allowed')
    if event['resource_id'] not in visible_resources:
        raise PermissionError('Resource is not visible')
    return {'action':event['action'],'resource_id':event['resource_id']}
# END CORE


def main():
    owner = Identity('tenant-a','user-a')
    event = {'revision':2,'action':'open_detail','resource_id':'r1'}
    assert authorize(owner,owner,event,2,{'r1'})['action'] == 'open_detail'
    cases = [
        (Identity('tenant-b','user-a'),event),
        (owner,{**event,'revision':1}),
        (owner,{**event,'action':'execute_javascript'}),
        (owner,{**event,'resource_id':'r2'}),
        (owner,{**event,'tenant':'tenant-a'}),
    ]
    rejected = 0
    for identity, item in cases:
        try:
            authorize(identity,owner,item,2,{'r1'})
        except (ValueError, PermissionError):
            rejected += 1
    assert rejected == len(cases)
    record = {'passed':True,'invalid_events_rejected':rejected,
              'scope':'Application checks only; no token verification, database, transport or UI renderer'}
    out = Path(__file__).parent / 'results/application-boundary.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
