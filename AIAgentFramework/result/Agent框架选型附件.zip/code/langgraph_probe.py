"""Real LangGraph probes; synthetic data only, no model or platform credentials.

SQLite is a local demonstration backend, not a production recommendation.
Run without arguments to execute subprocess recovery and authorization probes.
"""
import concurrent.futures
from contextlib import contextmanager
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
import tempfile
import time
from typing import TypedDict

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt


class State(TypedDict, total=False):
    resource_ids: list[str]
    report: str


@contextmanager
def connect(folder):
    db = sqlite3.connect(str(Path(folder) / 'business.sqlite'), timeout=20)
    db.execute('PRAGMA busy_timeout=20000')
    try:
        with db:
            yield db
    finally:
        db.close()


def count(folder, name):
    with connect(folder) as db:
        db.execute('INSERT INTO counters VALUES (?,1) ON CONFLICT(name) DO UPDATE SET n=n+1', (name,))


def graph_for(folder, saver, crash=False):
    def prepare(state):
        count(folder, 'prepare')
        return {}

    def ask(state):
        count(folder, 'before_interrupt')
        answer = interrupt({'kind': 'resource_scope_form', 'fields': ['resource_ids', 'time_range'],
                            'surface_id': 'scope-1', 'revision': 1})
        if set(answer) != {'resource_ids', 'time_range'} or answer['resource_ids'] != ['vm-1']:
            raise ValueError('Invalid or unauthorized resource selection')
        return {'resource_ids': answer['resource_ids']}

    def effect(state):
        count(folder, 'effect_attempt')
        # Simulates an external service's idempotency ledger in a SEPARATE DB.
        # A real remote API must provide equivalent semantics or require reconciliation.
        with connect(folder) as db:
            db.execute('INSERT OR IGNORE INTO effects VALUES (?,?)', ('tenant-a/run-1/report-1', 'created'))
        if crash:
            os._exit(73)  # after effect commit, before graph checkpoint acknowledgement
        return {'report': 'report-1'}

    builder = StateGraph(State)
    for name, node in [('prepare', prepare), ('ask', ask), ('effect', effect)]:
        builder.add_node(name, node)
    builder.add_edge(START, 'prepare')
    builder.add_edge('prepare', 'ask')
    builder.add_edge('ask', 'effect')
    builder.add_edge('effect', END)
    return builder.compile(checkpointer=saver)


def child(folder, phase):
    config = {'configurable': {'thread_id': 'opaque-server-owned-thread'}}
    with SqliteSaver.from_conn_string(str(Path(folder) / 'checkpoints.sqlite')) as saver:
        graph = graph_for(folder, saver, crash=phase == 'crash')
        if phase == 'start':
            result = graph.invoke({}, config, durability='sync')
            assert result['__interrupt__']
            print(json.dumps({'interrupt': result['__interrupt__'][0].value}))
        elif phase == 'crash':
            graph.invoke(Command(resume={'resource_ids': ['vm-1'], 'time_range': 'last7d'}), config, durability='sync')
        else:
            result = graph.invoke(None, config, durability='sync')
            assert result['report'] == 'report-1'
            assert graph.get_state(config).next == ()
            # Deliberately bypasses an app gateway: the checkpointer does NOT authenticate callers.
            raw_read = graph.get_state(config).values
            print(json.dumps({'report': result['report'], 'raw_checkpointer_read_without_identity': bool(raw_read)}))


def claim(folder, tenant='tenant-a', user='user-a', revision=1, epoch=3, action='submit'):
    with connect(folder) as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT tenant,user,revision,epoch,expires,status FROM pending WHERE id=?', ('surface-1',)).fetchone()
        if (tenant, user) != row[:2]:
            return 'denied_identity'
        if revision != row[2] or epoch != row[3]:
            return 'denied_stale'
        if row[4] < time.time() or action != 'submit':
            return 'denied_action_or_expiry'
        if row[5] != 'waiting':
            return 'duplicate'
        db.execute("UPDATE pending SET status='queued' WHERE id='surface-1' AND status='waiting'")
        # Acceptance and enqueue are atomic; do not use nonce-consumed -> enqueue as two commits.
        db.execute('INSERT INTO outbox VALUES (?,?)', ('surface-1', 'resume'))
        return 'accepted'


def main():
    with tempfile.TemporaryDirectory(prefix='roma-probe-') as folder:
        with connect(folder) as db:
            db.executescript('''
                CREATE TABLE counters(name TEXT PRIMARY KEY,n INTEGER);
                CREATE TABLE effects(id TEXT PRIMARY KEY,status TEXT);
                CREATE TABLE pending(id TEXT PRIMARY KEY,tenant TEXT,user TEXT,revision INTEGER,epoch INTEGER,expires REAL,status TEXT);
                CREATE TABLE outbox(id TEXT PRIMARY KEY,payload TEXT);
            ''')
            db.execute('INSERT INTO pending VALUES (?,?,?,?,?,?,?)', ('surface-1','tenant-a','user-a',1,3,time.time()+60,'waiting'))
        phases = []
        for phase, expected in [('start', 0), ('crash', 73), ('recover', 0)]:
            p = subprocess.run([sys.executable, __file__, '--child', folder, phase], capture_output=True, text=True, timeout=45)
            assert p.returncode == expected, (phase, p.returncode, p.stderr)
            phases.append({'phase': phase, 'returncode': p.returncode, 'stdout': p.stdout.strip()})
        with connect(folder) as db:
            counters = dict(db.execute('SELECT name,n FROM counters'))
            effects = db.execute('SELECT count(*) FROM effects').fetchone()[0]
        assert counters == {'prepare': 1, 'before_interrupt': 2, 'effect_attempt': 2}, counters
        assert effects == 1
        denied = [claim(folder, tenant='tenant-b'), claim(folder, user='user-b'),
                  claim(folder, revision=0), claim(folder, epoch=2), claim(folder, action='delete')]
        assert all(x.startswith('denied') for x in denied)
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:
            claims = list(pool.map(lambda _: claim(folder), range(20)))
        assert claims.count('accepted') == 1 and claims.count('duplicate') == 19
        with connect(folder) as db:
            outbox = db.execute('SELECT count(*) FROM outbox').fetchone()[0]
            db.execute("UPDATE pending SET expires=0 WHERE id='surface-1'")
        expired = claim(folder)
        assert outbox == 1 and expired == 'denied_action_or_expiry'
        result = {
            'python': sys.version, 'platform': platform.platform(),
            'versions': {p: importlib.metadata.version(p) for p in ['langgraph','langgraph-checkpoint','langgraph-checkpoint-sqlite']},
            'phases': phases, 'counters': counters, 'effects_committed': effects,
            'cross_identity_and_stale_rejections': denied, 'concurrent_submissions': 20,
            'accepted': claims.count('accepted'), 'duplicates': claims.count('duplicate'),
            'outbox_rows': outbox, 'expiry': expired, 'passed': True,
            'limitations': ['No LLM, MCP or real cloud API', 'SQLite local durability, not database HA',
                            'Gateway claim logic is our code, not LangGraph authorization',
                            'External effect uniqueness supplied by simulated downstream ledger']}
        output = Path(__file__).parent / 'results' / 'langgraph-probe.json'
        output.parent.mkdir(exist_ok=True)
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--child':
        child(sys.argv[2], sys.argv[3])
    else:
        main()
